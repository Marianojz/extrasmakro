# ROADMAP.md — Horas Extras V2

> **Documento congelado.**
> Éste es el plan de desarrollo aprobado. No modificar sin registrar la razón del cambio al final del documento.
> Última actualización: 25/02/2026

---

## Objetivo del proyecto

Construir una aplicación web para **gestionar convocatorias y horas extras** con:
- Reglas operativas precisas (turnos, tipos de horas, sábados).
- Motor de reputación por empleado con descargos.
- Algoritmo de prioridad transparente y auditable.
- Implementación inicial **100 % offline** (sin dependencias).
- Cableado listo para migrar a **Firebase + GitHub + Vercel** cuando haya internet.

---

## Estado general a 25/02/2026

| Fase | Estado |
|--|--|
| Fase 0 — Estructura base | ✅ Completa |
| Fase 1 — Implementación offline v1 | ✅ Completa |
| Fase 2 — Mejoras UX + bugs corregidos | ✅ Completa |
| Fase 3 — Funcionalidades operativas avanzadas | ✅ Completa |
| Fase 4 — Cableado Firebase + despliegue | 🔲 Pendiente (requiere internet) |
| Fase 5 — Producción y control | 🔲 Pendiente |

---

## Fase 0 — Estructura base ✅

- [x] Estructura de carpetas (`public/`, `src/`)
- [x] `public/index.html` limpio (solo shell, sin markup muerto)
- [x] `src/styles.css` base
- [x] `package.json` placeholder
- [x] `CONTEXT.md` con especificación completa
- [x] `README.md` con instrucciones de uso

---

## Fase 1 — Implementación offline ✅

- [x] Adapter pattern de storage (`src/storage/`)
  - `adapter.js` — interfaz + INITIAL_STATE canónico
  - `localStorageAdapter.js` — implementación offline
  - `firebaseAdapter.js` — stub comentado para futuro
  - `index.js` — selector por `FIREBASE_ENABLED`
- [x] `src/config.js` — configuración global centralizada
- [x] `src/store.js` — re-export del adapter activo
- [x] `src/models.js` — lógica de negocio completa:
  - Empleados (CRUD)
  - Convocatorias (máx 2 intentos, estados terminales)
  - Sábados (registro de horas, recuperación de reputación)
  - Días hábiles (Caso A turno mañana / Caso B turno tarde)
  - Descargos (ventana 48 h, reversión de penalización)
  - Audit logs (asignaciones fuera del top)
  - Scoring v2.1 con penalización por baja confiabilidad
  - Import/Export de estado completo
- [x] `src/utils.js` — `toCSV`, `parseCSV` (exportada), `downloadBlob`, `makeFilename`

---

## Fase 2 — Mejoras UX + bugs críticos corregidos ✅

### Bugs corregidos
- [x] `generateId()` reseteaba el contador — ahora incrementa correctamente
- [x] `openPrintableReport()` usaba variable `month` sin declarar
- [x] `parseCSV` no estaba exportada en `utils.js`
- [x] `addCallAttempt`: `no_respondio` cerraba prematuramente al 1er intento
- [x] `index.html` tenía markup muerto del prototipo (sección `#add-hours`)

### Mejoras de UX
- [x] Navegación por 5 tabs: Empleados | Convocatorias | Sábados | Estadísticas | Config
- [x] Sistema de **toasts** (reemplaza todos los `alert()` / `confirm()` / `prompt()`)
- [x] **Modales de formulario** para todas las operaciones de entrada de datos
- [x] Tabla de empleados con búsqueda, paginación y badges visuales
- [x] Tabla de ranking con score, confiabilidad, reputación y trofeos top-3
- [x] Panel de estadísticas con 4 tarjetas resumen
- [x] Flujo de convocatorias: modal de creación + modal de intento separados
- [x] Gestión de descargos desde el modal de detalle de empleado
- [x] Confirmación de asignación fuera del top con audit log integrado
- [x] Vista imprimible con auto-print (`window.print()`)
- [x] Importar JSON completo (reemplaza todos los datos)
- [x] Exportar JSON, CSV empleados, CSV ranking, CSV eventos filtrados
- [x] Panel de config: turno semana, importar, resetear datos
- [x] Indicador de turno activo en el header (siempre visible)
- [x] CSS completamente renovado (custom properties, responsive, animaciones)

---

## Fase 3 — Funcionalidades operativas avanzadas ✅

### 3.1 Flujo de intención de sábado (viernes)
- [x] UI para que el supervisor registre qué empleados se anotaron con intención el viernes
- [x] Vista de asignaciones de sábado con estado por empleado (anotado, asignado, trabajó, faltó)

### 3.2 Gestión de turno semanal avanzada
- [x] Calendario visual de turno por semana (historial de cambios de `currentShiftWeek`)
- [x] Historial guardado en `systemConfig.shiftHistory`

### 3.3 Cierre automático de descargos vencidos
- [x] Función `expireStaleDescargas()` que cierra incidentes `pendiente_descargo` cuya ventana de 48 h venció
- [x] Llamada al iniciar la app; banner de alerta persistente si se cerraron descargos

### 3.4 Dashboard de jefe (vista global)
- [x] Tabla “Top incumplidores” en Estadísticas
- [x] Tabla de audit log completo con fecha, supervisor, empleado asignado, motivo y detalle

### 3.5 Recuperación mensual de reputación
- [x] Función `applyMonthlyRecovery(YYYY-MM)` → empleados sin incidentes en el mes reciben +2 pts
- [x] UI en Config para ejecutar el cierre mensual

### 3.6 Notificación de eventuales vencidos
- [x] `deactivateExpiredEventuals()` llama al inicio y retorna IDs desactivados
- [x] Banner persistente (dismissable) en la barra superior cuando hay empleados vencidos

### 3.7 Reporte imprimible mejorado
- [x] Filtro por turno, tipo de empleado y activos-only
- [x] Campo de nombre de empresa personalizable
- [x] Tabla con badges visuales de turno y tipo
- [x] Sección de firmas, encabezado con empresa y fecha de generación

### 3.8 Validaciones adicionales
- [x] Detección automática de `eventual_comun` vencidos al iniciar la app
- [x] Protección contra duplicación de nombres al agregar empleados

---

## Fase 4 — Cableado Firebase + despliegue 🔲

> Requiere: internet, `npm install firebase`, credenciales Firebase reales.

### 4.1 Preparación Firebase
- [ ] Completar `src/firebaseConfig.js` con credenciales del proyecto
- [ ] `npm install firebase`
- [ ] Cambiar `FIREBASE_ENABLED: true` en `src/config.js`
- [ ] Descomentar código en `src/storage/firebaseAdapter.js`
- [ ] Adaptar `models.js` y `app.js` para `await` en calls al store

### 4.2 Estructura Firestore
- [ ] Crear colecciones: `employees`, `callEvents`, `saturdayEvents`, `auditLogs`, `systemConfig`
- [ ] Configurar índices para queries por fecha y por empleado
- [ ] Script de migración: importar export JSON del modo offline a Firestore

### 4.3 Autenticación
- [ ] Firebase Auth (email/password) para supervisores y jefe
- [ ] Roles: `supervisor` (escribe convocatorias/sábados) | `jefe` (lee todo, exporta)
- [ ] Guard de autenticación en `app.js` antes de montar la UI

### 4.4 Reglas de seguridad Firestore
- [ ] Escritura solo para supervisores en paths seguros
- [ ] Lectura de `auditLogs` solo para jefe
- [ ] Impedir escritura directa de `employees.stats` desde el cliente

### 4.5 Despliegue
- [ ] Repositorio en GitHub (privado)
- [ ] Conectar con Vercel
- [ ] Variables de entorno en Vercel para credenciales Firebase
- [ ] CI/CD automático en cada push a `main`

---

## Fase 5 — Producción y control 🔲

- [ ] Pruebas de aceptación con supervisores reales (escenarios completos)
- [ ] Revisión legal/sindical del modelo de reputación y descargos
- [ ] Política de retención de datos (cuánto tiempo guardar callEvents, auditLogs)
- [ ] Backups automáticos de Firestore (exportaciones programadas)
- [ ] Generación automática de reportes mensuales (Cloud Functions o cron Vercel)
- [ ] Notificaciones (email/push) para descargos pendientes próximos a vencer

---

## Historial de cambios al roadmap

| Fecha | Cambio | Razón |
|--|--|--|
| 25/02/2026 | Fase 3 completada — todas las funcionalidades operativas implementadas | Se completaron: sábados 3 fases, historial turno, mantenimiento automático, reporte mejorado, banner de alertas |
