# Horas Extras V2

Proyecto inicial para gestionar horas extras. Creado sin dependencias instaladas (offline).

Estructura generada:
- `public/index.html` — página principal (estática)
- `src/app.js` — lógica cliente (ES modules)
- `src/firebaseConfig.js` — placeholders para Firebase
- `src/styles.css` — estilos básicos
- `package.json` — manifest de ejemplo (scripts placeholders)
- `CONTEXT.md` — contexto y restricciones del proyecto

Siguientes pasos recomendados (cuando haya internet):
- Completar `src/firebaseConfig.js` con las credenciales reales.
- Ejecutar `npm install` e instalar dependencias (si elegís usar un bundler o framework).
- Configurar repositorio en GitHub y despliegue en Vercel.
