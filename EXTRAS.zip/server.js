/**
 * server.js — Servidor HTTP mínimo para desarrollo local (sin dependencias npm).
 * Sirve todos los archivos del proyecto desde la raíz del workspace.
 *
 * Uso:
 *   node server.js          → puerto 3000
 *   node server.js 8080     → puerto personalizado
 *
 * URL de la app: http://localhost:3000/public/index.html
 */

const http  = require('http');
const fs    = require('fs');
const path  = require('path');
const url   = require('url');

const PORT = parseInt(process.argv[2] || '3000', 10);
const ROOT = __dirname;

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js'  : 'text/javascript; charset=utf-8',
  '.css' : 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.ico' : 'image/x-icon',
  '.png' : 'image/png',
  '.svg' : 'image/svg+xml',
};

const server = http.createServer((req, res) => {
  const pathname  = url.parse(req.url).pathname;
  const safePath  = pathname === '/' ? '/public/index.html' : pathname;
  const filePath  = path.join(ROOT, safePath);

  // Seguridad: no salir de la raíz del proyecto
  if (!filePath.startsWith(ROOT)) {
    res.writeHead(403); res.end('Forbidden'); return;
  }

  fs.readFile(filePath, (err, data) => {
    if (err) {
      if (err.code === 'ENOENT') {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('404 — Archivo no encontrado: ' + safePath);
      } else {
        res.writeHead(500); res.end('Error interno');
      }
      return;
    }
    const ext  = path.extname(filePath).toLowerCase();
    const mime = MIME[ext] || 'application/octet-stream';
    res.writeHead(200, { 'Content-Type': mime });
    res.end(data);
  });
});

server.listen(PORT, '127.0.0.1', () => {
  console.log('');
  console.log('  ⏱  Horas Extras V2 — servidor de desarrollo');
  console.log('');
  console.log('  App    →  http://localhost:' + PORT + '/public/index.html');
  console.log('  Raíz   →  http://localhost:' + PORT + '/');
  console.log('');
  console.log('  Para detener el servidor: Ctrl + C');
  console.log('');
});
