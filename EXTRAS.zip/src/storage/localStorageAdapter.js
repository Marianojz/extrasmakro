/**
 * LocalStorageAdapter — Implementación offline usando window.localStorage.
 * ─────────────────────────────────────────────────────────────────────────────
 * Este es el adapter activo mientras FIREBASE_ENABLED = false en config.js.
 * Todos los métodos son SINCRÓNICOS.
 * ─────────────────────────────────────────────────────────────────────────────
 */

import { INITIAL_STATE } from './adapter.js';
import { APP_CONFIG } from '../config.js';

const KEY = APP_CONFIG.STORAGE_KEY;

/**
 * Carga el estado completo desde localStorage.
 * Si no existe o está corrupto, devuelve estado inicial limpio.
 * @returns {import('./adapter.js').AppState}
 */
function load() {
  const raw = localStorage.getItem(KEY);
  if (!raw) {
    const fresh = structuredClone(INITIAL_STATE);
    localStorage.setItem(KEY, JSON.stringify(fresh));
    return fresh;
  }
  try {
    const parsed = JSON.parse(raw);
    // Garantizar que todos los campos del esquema existan (migración suave)
    return Object.assign(structuredClone(INITIAL_STATE), parsed);
  } catch (e) {
    console.error('[LocalStorageAdapter] Datos corruptos — reiniciando.', e);
    const fresh = structuredClone(INITIAL_STATE);
    localStorage.setItem(KEY, JSON.stringify(fresh));
    return fresh;
  }
}

/**
 * Guarda el estado completo en localStorage.
 * @param {import('./adapter.js').AppState} state
 */
function save(state) {
  try {
    localStorage.setItem(KEY, JSON.stringify(state));
  } catch (e) {
    // Puede fallar si localStorage está lleno (QuotaExceededError)
    console.error('[LocalStorageAdapter] Error al guardar.', e);
    throw new Error('No se pudo guardar. El almacenamiento local está lleno. Exportá los datos y limpiá el storage.');
  }
}

/**
 * Elimina todos los datos y devuelve el estado inicial.
 * @returns {import('./adapter.js').AppState}
 */
function reset() {
  localStorage.removeItem(KEY);
  return load();
}

export default { load, save, reset };
