/**
 * models.js — Lógica de negocio de Horas Extras V2
 * ─────────────────────────────────────────────────────────────────────────────
 * Todas las operaciones de dominio pasan por aquí.
 * El acceso a datos se delega a store (adapter activo: localStorage o Firebase).
 * ─────────────────────────────────────────────────────────────────────────────
 */

import store from './store.js';
import { APP_CONFIG } from './config.js';

// ─── Utilidades internas ─────────────────────────────────────────────────────

function now() {
  return new Date().toISOString();
}

/**
 * Genera un ID numérico único autoincremental.
 * BUG CORREGIDO: la versión anterior hacía state.nextIdCounter = id
 * reseteando el contador al valor pre-increment en cada llamada.
 */
function generateId() {
  const state = store.load();
  const id = state.nextIdCounter;
  state.nextIdCounter = id + 1;
  store.save(state);
  return String(id);
}

/**
 * Aplica una penalización de reputación y crea el incidente asociado.
 */
function applyPenalty(emp, delta, reason) {
  const incident = {
    id: 'inc_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
    ts: now(),
    delta,
    reason,
    status: 'pendiente_descargo',
    descargo: null,
  };
  emp.reputation = Math.max(0, Math.min(100, emp.reputation + delta));
  emp.incidents.push(incident);
  return incident;
}

// ─── Empleados ───────────────────────────────────────────────────────────────

function initEmployee({ name, turno_base, tipo, antiguedad_meses = 0, activo = true, fecha_fin = null, telefono = '', legajo = '', puesto = '' }) {
  if (!name?.trim()) throw new Error('El nombre es requerido.');
  if (!['mañana', 'tarde'].includes(turno_base)) throw new Error('turno_base debe ser "mañana" o "tarde".');
  if (!['efectivo', 'eventual_comun', 'eventual_especial'].includes(tipo)) throw new Error('tipo inválido.');
  if (tipo === 'eventual_comun' && !fecha_fin) throw new Error('Fecha fin requerida para eventual_comun.');

  // generateId ya hace load+save internamente, re-leer para tener el estado actualizado
  const id = generateId();
  const freshState = store.load();
  const employee = {
    id,
    name: name.trim(),
    turno_base,
    tipo,
    antiguedad_meses,
    activo,
    fecha_fin: fecha_fin || null,
    telefono: (telefono || '').trim(),
    legajo:   (legajo   || '').trim(),
    puesto:   (puesto   || '').trim(),
    reputation: APP_CONFIG.INITIAL_REPUTATION,
    stats: {
      horas_50: 0, horas_100: 0, convocado: 0, acepto: 0,
      rechazo: 0, no_respondio: 0, numero_incorrecto: 0,
      falto: 0, sabados_trabajados: 0,
    },
    incidents: [],
    createdAt: now(),
  };

  freshState.employees[id] = employee;
  freshState.employeesList.push(id);
  store.save(freshState);
  return employee;
}

function updateEmployee(id, patch) {
  const state = store.load();
  const emp = state.employees[id];
  if (!emp) throw new Error('Empleado no encontrado: ' + id);
  Object.assign(emp, patch);
  store.save(state);
  return emp;
}

function listEmployees() {
  const state = store.load();
  return state.employeesList.map(id => state.employees[id]).filter(Boolean);
}

function getEmployee(id) {
  return store.load().employees[id] || null;
}

// ─── Convocatorias ───────────────────────────────────────────────────────────

function createCallEvent({ empleado_id, fecha, tipo_extra, supervisor_id = null }) {
  const state = store.load();
  if (!state.employees[empleado_id]) throw new Error('Empleado no encontrado: ' + empleado_id);

  const id = 'call_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6);
  const event = {
    id, empleado_id, fecha, tipo_extra,
    attempts: [], resultado_final: null,
    supervisor_id, timestamp: now(),
  };
  state.callEvents[id] = event;
  state.employees[empleado_id].stats.convocado += 1;
  store.save(state);
  return event;
}

function addCallAttempt(callId, { status, note = '' }) {
  const VALID_STATUSES = ['confirmado', 'rechazo', 'no_respondio', 'numero_incorrecto', 'atendio_otro', 'falto'];
  if (!VALID_STATUSES.includes(status)) throw new Error('Estado inválido: ' + status);

  const state = store.load();
  const ev = state.callEvents[callId];
  if (!ev) throw new Error('Convocatoria no encontrada: ' + callId);
  if (ev.resultado_final) throw new Error('Convocatoria ya cerrada: ' + ev.resultado_final);
  if (ev.attempts.length >= APP_CONFIG.MAX_CALL_ATTEMPTS) {
    throw new Error('Máximo de intentos alcanzado (' + APP_CONFIG.MAX_CALL_ATTEMPTS + ').');
  }

  ev.attempts.push({ ts: now(), status, note });

  const isSecondAttempt = ev.attempts.length >= APP_CONFIG.MAX_CALL_ATTEMPTS;
  const terminalStates = ['confirmado', 'rechazo', 'numero_incorrecto', 'falto'];
  const isTerminal = terminalStates.includes(status) || (status === 'no_respondio' && isSecondAttempt);

  if (isTerminal) {
    ev.resultado_final = status;
    const emp = state.employees[ev.empleado_id];
    if (emp) {
      const P = APP_CONFIG.REPUTATION_PENALTIES;
      switch (status) {
        case 'confirmado':        emp.stats.acepto           += 1; break;
        case 'rechazo':           emp.stats.rechazo          += 1; applyPenalty(emp, P.rechazo,           'rechazo'); break;
        case 'no_respondio':      emp.stats.no_respondio     += 1; applyPenalty(emp, P.no_respondio,      'no_respondio'); break;
        case 'numero_incorrecto': emp.stats.numero_incorrecto+= 1; applyPenalty(emp, P.numero_incorrecto, 'numero_incorrecto'); break;
        case 'falto':             emp.stats.falto            += 1; applyPenalty(emp, P.falto,             'falto'); break;
      }
    }
  }

  store.save(state);
  return ev;
}

// ─── Descargos ───────────────────────────────────────────────────────────────

function submitDescargo(employeeId, incidentId, text) {
  const state = store.load();
  const emp = state.employees[employeeId];
  if (!emp) throw new Error('Empleado no encontrado: ' + employeeId);
  const inc = emp.incidents.find(i => i.id === incidentId);
  if (!inc) throw new Error('Incidente no encontrado: ' + incidentId);
  if (inc.status !== 'pendiente_descargo') throw new Error('El incidente ya fue resuelto.');
  if (Date.now() - new Date(inc.ts).getTime() > APP_CONFIG.DESCARGO_WINDOW_MS) {
    inc.status = 'cerrado_sin_descargo';
    store.save(state);
    throw new Error('Venció el plazo de 48h para presentar descargo.');
  }
  inc.descargo = { text: text.trim(), ts: now() };
  store.save(state);
  return inc;
}

function resolveDescargo(employeeId, incidentId, approved) {
  const state = store.load();
  const emp = state.employees[employeeId];
  if (!emp) throw new Error('Empleado no encontrado: ' + employeeId);
  const inc = emp.incidents.find(i => i.id === incidentId);
  if (!inc) throw new Error('Incidente no encontrado: ' + incidentId);
  if (inc.status !== 'pendiente_descargo') throw new Error('Incidente ya resuelto: ' + inc.status);
  inc.status = approved ? 'revertido' : 'rechazado';
  inc.resolvedAt = now();
  if (approved) {
    // inc.delta es negativo (ej. -15), revertir suma el valor absoluto
    emp.reputation = Math.max(0, Math.min(100, emp.reputation - inc.delta));
  }
  store.save(state);
  return inc;
}

// ─── Sábados ─────────────────────────────────────────────────────────────────

function recordSaturdayWorked(employeeId, dateKey, hoursWorked) {
  if (!dateKey || !/^\d{4}_\d{2}_\d{2}$/.test(dateKey)) throw new Error('dateKey debe tener formato YYYY_MM_DD');
  if (hoursWorked <= 0) throw new Error('Las horas deben ser mayor a 0.');
  const state = store.load();
  const emp = state.employees[employeeId];
  if (!emp) throw new Error('Empleado no encontrado: ' + employeeId);
  if (!state.saturdayEvents[dateKey]) {
    state.saturdayEvents[dateKey] = { date: dateKey, intentions: [], assignments: [], records: [] };
  }
  state.saturdayEvents[dateKey].records.push({ employeeId, hours: hoursWorked, ts: now() });
  emp.stats.horas_100 += hoursWorked;
  emp.stats.sabados_trabajados += 1;
  emp.reputation = Math.min(100, emp.reputation + APP_CONFIG.REPUTATION_RECOVERY.extra_cumplida);
  store.save(state);
}

function createSaturdayEvent(dateKey, { intentBy = [], supervisorAssigned = null }) {
  if (!dateKey || !/^\d{4}_\d{2}_\d{2}$/.test(dateKey)) throw new Error('dateKey debe tener formato YYYY_MM_DD');
  const state = store.load();
  if (!state.saturdayEvents[dateKey]) {
    state.saturdayEvents[dateKey] = { date: dateKey, intentions: [], assignments: [], records: [] };
  }
  const ev = state.saturdayEvents[dateKey];
  if (intentBy.length) ev.intentions.push(...intentBy.map(id => ({ employeeId: id, ts: now() })));
  if (supervisorAssigned) ev.assignments.push({ supervisorAssigned, ts: now() });
  store.save(state);
  return ev;
}

// ─── Horas hábiles ───────────────────────────────────────────────────────────

/**
 * Registra horas extras de un día hábil según el turno del empleado.
 * Caso A: turno mañana → +3 horas_50
 * Caso B: turno tarde  → +3 horas_100
 */
function recordWeekdayExtra(employeeId) {
  const state = store.load();
  const emp = state.employees[employeeId];
  if (!emp) throw new Error('Empleado no encontrado: ' + employeeId);
  if (emp.turno_base === 'mañana') {
    emp.stats.horas_50 += 3;
  } else {
    emp.stats.horas_100 += 3;
  }
  emp.reputation = Math.min(100, emp.reputation + APP_CONFIG.REPUTATION_RECOVERY.extra_cumplida);
  store.save(state);
  return emp;
}

// ─── Audit Logs ──────────────────────────────────────────────────────────────

function addAuditLog({ supervisor_id, chosen_employee, suggested_top, reason, note = '' }) {
  const state = store.load();
  const log = {
    id: 'audit_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
    ts: now(), supervisor_id, chosen_employee, suggested_top, reason, note,
  };
  state.auditLogs.push(log);
  store.save(state);
  return log;
}

// ─── Ranking / Scoring ───────────────────────────────────────────────────────

/**
 * Fórmula v2.1: score = (total_horas * 3) + convocado - (reputationScore * 0.5)
 * Menor score → mayor prioridad. Penalización +20 si confiabilidad < 0.5.
 */
function computeScore(emp) {
  const total_horas = (emp.stats.horas_50 || 0) + (emp.stats.horas_100 || 0);
  const convocado   = emp.stats.convocado || 0;
  const acepto      = emp.stats.acepto || 0;
  const reputationScore = emp.reputation || 0;
  const confiabilidad   = convocado > 0 ? acepto / convocado : 1;
  let score = (total_horas * 3) + convocado - (reputationScore * 0.5);
  if (confiabilidad < 0.5 && convocado > 0) score += 20;
  return { score, total_horas, convocado, reputationScore, confiabilidad };
}

function suggestionList() {
  const state = store.load();
  return state.employeesList
    .map(id => state.employees[id])
    .filter(e => e && e.activo)
    .map(e => ({ ...e, __meta: computeScore(e) }))
    .sort((a, b) => a.__meta.score - b.__meta.score);
}

// ─── Config del sistema ──────────────────────────────────────────────────────

function getSystemConfig() {
  return store.load().systemConfig;
}

function updateSystemConfig(patch) {
  const state = store.load();
  Object.assign(state.systemConfig, patch);
  store.save(state);
  return state.systemConfig;
}

// ─── Export / Import ─────────────────────────────────────────────────────────

function exportState() {
  return store.load();
}

function importState(data) {
  if (!data || typeof data !== 'object') throw new Error('Datos inválidos.');
  store.save(data);
}

// ─── Sábados: intenciones y asignaciones individuales ─────────────────────────

function ensureSatEvent(state, dateKey) {
  if (!state.saturdayEvents[dateKey]) {
    state.saturdayEvents[dateKey] = { date: dateKey, intentions: [], assignedEmployees: [], assignments: [], records: [] };
  }
  if (!state.saturdayEvents[dateKey].assignedEmployees) {
    state.saturdayEvents[dateKey].assignedEmployees = [];
  }
  return state.saturdayEvents[dateKey];
}

/**
 * Agrega a un empleado a la lista de intenciones de un sábado.
 * Idempotente: lanza error si ya manifestó intención.
 */
function addSaturdayIntention(dateKey, employeeId) {
  if (!dateKey || !/^\d{4}_\d{2}_\d{2}$/.test(dateKey)) throw new Error('dateKey debe tener formato YYYY_MM_DD');
  const state = store.load();
  if (!state.employees[employeeId]) throw new Error('Empleado no encontrado: ' + employeeId);
  const ev = ensureSatEvent(state, dateKey);
  if (ev.intentions.some(i => i.employeeId === employeeId)) {
    throw new Error('El empleado ya manifestó intención para ese sábado.');
  }
  ev.intentions.push({ employeeId, ts: now() });
  store.save(state);
}

/** Elimina la intención de un empleado para un sábado. */
function removeSaturdayIntention(dateKey, employeeId) {
  const state = store.load();
  const ev = state.saturdayEvents?.[dateKey];
  if (!ev) return;
  ev.intentions = (ev.intentions || []).filter(i => i.employeeId !== employeeId);
  store.save(state);
}

/**
 * Asigna formalmente a un empleado a trabajar un sábado.
 * Registra quién hizo la asignación (supervisorId).
 */
function assignEmployeeToSaturday(dateKey, employeeId, supervisorId) {
  if (!dateKey || !/^\d{4}_\d{2}_\d{2}$/.test(dateKey)) throw new Error('dateKey debe tener formato YYYY_MM_DD');
  const state = store.load();
  if (!state.employees[employeeId]) throw new Error('Empleado no encontrado: ' + employeeId);
  const ev = ensureSatEvent(state, dateKey);
  if (ev.assignedEmployees.some(a => a.employeeId === employeeId)) {
    throw new Error('El empleado ya está asignado a ese sábado.');
  }
  ev.assignedEmployees.push({ employeeId, supervisorId: supervisorId || '', ts: now() });
  store.save(state);
}

/** Cancela la asignación de un empleado a un sábado. */
function removeAssignmentFromSaturday(dateKey, employeeId) {
  const state = store.load();
  const ev = state.saturdayEvents?.[dateKey];
  if (!ev) return;
  ev.assignedEmployees = (ev.assignedEmployees || []).filter(a => a.employeeId !== employeeId);
  store.save(state);
}

// ─── Turno semanal con historial ────────────────────────────────────────────

/**
 * Actualiza el turno activo de la semana y lo registra en el historial.
 * El historial almacena el lunes de la semana actual como ‘weekStart’.
 * Mantiene las últimas 52 entradas (1 año).
 */
function registerShiftWeekChange(turno) {
  if (!['mañana', 'tarde'].includes(turno)) throw new Error('turno debe ser "mañana" o "tarde".');
  const state = store.load();
  if (!state.systemConfig.shiftHistory) state.systemConfig.shiftHistory = [];

  const today = new Date();
  const dow = today.getDay(); // 0=sun
  const monday = new Date(today);
  monday.setDate(today.getDate() - (dow === 0 ? 6 : dow - 1));
  const weekStart = monday.toISOString().slice(0, 10);

  state.systemConfig.currentShiftWeek = turno;
  // Reemplazar entrada existente para esta semana si ya existe
  state.systemConfig.shiftHistory = state.systemConfig.shiftHistory.filter(h => h.weekStart !== weekStart);
  state.systemConfig.shiftHistory.push({ weekStart, turno, changedAt: now() });
  // Guardar solo el último año
  if (state.systemConfig.shiftHistory.length > 52) {
    state.systemConfig.shiftHistory = state.systemConfig.shiftHistory.slice(-52);
  }
  store.save(state);
  return state.systemConfig;
}

// ─── Operaciones de mantenimiento ──────────────────────────────────────────────

/**
 * Cierra automáticamente los descargos pendientes que superaron la ventana de
 * 48 h sin que el empleado presentara texto. Llamar al iniciar la app.
 * @returns {number} cantidad de incidentes cerrados
 */
function expireStaleDescargas() {
  const state = store.load();
  let count = 0;
  for (const id of state.employeesList) {
    const emp = state.employees[id];
    if (!emp) continue;
    for (const inc of emp.incidents) {
      if (inc.status === 'pendiente_descargo' && !inc.descargo) {
        const age = Date.now() - new Date(inc.ts).getTime();
        if (age > APP_CONFIG.DESCARGO_WINDOW_MS) {
          inc.status = 'cerrado_sin_descargo';
          inc.closedAt = now();
          count++;
        }
      }
    }
  }
  if (count > 0) store.save(state);
  return count;
}

/**
 * Desactiva empleados eventual_comun cuya fecha_fin ya pasó.
 * @returns {string[]} IDs de empleados desactivados
 */
function deactivateExpiredEventuals() {
  const state = store.load();
  const today = new Date().toISOString().slice(0, 10);
  const deactivated = [];
  for (const id of state.employeesList) {
    const emp = state.employees[id];
    if (!emp) continue;
    if (emp.tipo === 'eventual_comun' && emp.activo && emp.fecha_fin && emp.fecha_fin < today) {
      emp.activo = false;
      deactivated.push(id);
    }
  }
  if (deactivated.length) store.save(state);
  return deactivated;
}

/**
 * Aplica recuperación mensual de reputación (+mes_sin_incidentes) a empleados
 * activos sin penalizaciones en el mes indicado.
 * @param {string} yearMonth Formato "YYYY-MM"
 * @returns {number} cantidad de empleados beneficiados
 */
function applyMonthlyRecovery(yearMonth) {
  if (!yearMonth || !/^\d{4}-\d{2}$/.test(yearMonth)) {
    throw new Error('yearMonth debe ser "YYYY-MM". Ejemplo: "2026-02".');
  }
  const state = store.load();
  const prefix = yearMonth + '-';
  let count = 0;
  for (const id of state.employeesList) {
    const emp = state.employees[id];
    if (!emp || !emp.activo) continue;
    const hadPenalty = emp.incidents.some(
      inc => inc.ts.startsWith(prefix) && inc.delta < 0
    );
    if (!hadPenalty) {
      emp.reputation = Math.min(100, emp.reputation + APP_CONFIG.REPUTATION_RECOVERY.mes_sin_incidentes);
      count++;
    }
  }
  if (count > 0) store.save(state);
  return count;
}

/**
 * Devuelve todos los registros del audit log ordenados descendente por fecha.
 * @returns {object[]}
 */
function getAuditLogs() {
  const logs = store.load().auditLogs || [];
  return [...logs].sort((a, b) => b.ts.localeCompare(a.ts));
}

// ─── Planificación semanal ──────────────────────────────────────────────────────────

const DIAS_HABILES = ['lunes', 'martes', 'miercoles', 'jueves', 'viernes'];

/** Devuelve la clave ISO de la semana: 'YYYY-WNN' */
function getISOWeekKey(date = new Date()) {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  const weekNum = Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
  return d.getUTCFullYear() + '-W' + String(weekNum).padStart(2, '0');
}

/** Devuelve el lunes de una clave de semana como objeto Date (UTC). */
function getWeekMondayDate(weekKey) {
  const [yearStr, wStr] = weekKey.split('-W');
  const year = parseInt(yearStr);
  const week = parseInt(wStr);
  const jan4 = new Date(Date.UTC(year, 0, 4));
  const dow = jan4.getUTCDay() || 7;
  const monday = new Date(jan4);
  monday.setUTCDate(jan4.getUTCDate() - (dow - 1) + (week - 1) * 7);
  return monday;
}

/** Avanza o retrocede N semanas a partir de una clave. */
function shiftWeekKey(weekKey, delta) {
  const monday = getWeekMondayDate(weekKey);
  monday.setUTCDate(monday.getUTCDate() + delta * 7);
  return getISOWeekKey(new Date(monday.getUTCFullYear(), monday.getUTCMonth(), monday.getUTCDate()));
}

/**
 * Fija la disponibilidad de un empleado para la semana indicada.
 * @param {string} empId
 * @param {boolean} disponible
 * @param {string[]} dias  Subconjunto de DIAS_HABILES
 * @param {string|null} weekKey  Por defecto semana actual
 */
function setWeekAvailability(empId, disponible, dias = DIAS_HABILES, weekKey = null) {
  const wk = weekKey || getISOWeekKey();
  const state = store.load();
  if (!state.weekAvailability) state.weekAvailability = {};
  if (!state.weekAvailability[wk]) state.weekAvailability[wk] = {};
  state.weekAvailability[wk][empId] = { disponible: !!disponible, dias: dias || [] };
  store.save(state);
}

/**
 * Devuelve el mapa { empId: {disponible, dias} } para una semana.
 */
function getWeekAvailability(weekKey = null) {
  const wk = weekKey || getISOWeekKey();
  const state = store.load();
  return ((state.weekAvailability || {})[wk]) || {};
}

/** Limpia toda la planificación de una semana. */
function resetWeekAvailability(weekKey = null) {
  const wk = weekKey || getISOWeekKey();
  const state = store.load();
  if (!state.weekAvailability) state.weekAvailability = {};
  state.weekAvailability[wk] = {};
  store.save(state);
}

/** Actualiza múltiples empleados de una vez. */
function bulkSetWeekAvailability(map, weekKey = null) {
  const wk = weekKey || getISOWeekKey();
  const state = store.load();
  if (!state.weekAvailability) state.weekAvailability = {};
  state.weekAvailability[wk] = Object.assign({}, state.weekAvailability[wk] || {}, map);
  store.save(state);
}

/**
 * Elimina entradas de weekAvailability más viejas que maxWeeks semanas.
 * Llamar en el arranque para evitar que localStorage crezca indefinidamente.
 */
function purgeOldWeekAvailability(maxWeeks = 8) {
  const state = store.load();
  if (!state.weekAvailability) return;
  const currentKey = getISOWeekKey();
  const cutoff = shiftWeekKey(currentKey, -maxWeeks);
  let changed = false;
  for (const wk of Object.keys(state.weekAvailability)) {
    if (wk < cutoff) { delete state.weekAvailability[wk]; changed = true; }
  }
  if (changed) store.save(state);
}

// ─── Exports ─────────────────────────────────────────────────────────────────

export {
  initEmployee, updateEmployee, listEmployees, getEmployee,
  createCallEvent, addCallAttempt,
  submitDescargo, resolveDescargo,
  createSaturdayEvent, recordSaturdayWorked,
  addSaturdayIntention, removeSaturdayIntention,
  assignEmployeeToSaturday, removeAssignmentFromSaturday,
  recordWeekdayExtra,
  addAuditLog, getAuditLogs,
  suggestionList, computeScore,
  getSystemConfig, updateSystemConfig, registerShiftWeekChange,
  exportState, importState,
  expireStaleDescargas, deactivateExpiredEventuals, applyMonthlyRecovery,
  // Planificación semanal
  DIAS_HABILES,
  getISOWeekKey, getWeekMondayDate, shiftWeekKey,
  setWeekAvailability, getWeekAvailability,
  resetWeekAvailability, bulkSetWeekAvailability,
  purgeOldWeekAvailability,
};
