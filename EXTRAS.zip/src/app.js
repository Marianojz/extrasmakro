/**
 * app.js — Interfaz principal de Horas Extras V2
 * ─────────────────────────────────────────────────────────────────────────────
 * Estructura de la UI:
 *   Header + NavTabs
 *   ├── Tab: Empleados      (listado, alta, importar CSV)
 *   ├── Tab: Convocatorias  (iniciar llamada, registrar intentos)
 *   ├── Tab: Sábados        (registrar intenciones y horas)
 *   ├── Tab: Estadísticas   (ranking, scores, resumen global)
 *   └── Tab: Config         (turno semana, import/export, reset)
 * ─────────────────────────────────────────────────────────────────────────────
 */

import * as Models from './models.js';
import { toCSV, parseCSV, makeFilename, downloadBlob, toXLS } from './utils.js';

// ─── DOM helpers ─────────────────────────────────────────────────────────────

function el(tag, props = {}, ...children) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === 'class')     n.className = v;
    else if (k === 'html') n.innerHTML = v;
    else if (k.startsWith('on') && typeof v === 'function')
      n.addEventListener(k.slice(2).toLowerCase(), v);
    else n.setAttribute(k, v);
  }
  for (const c of children)
    n.append(typeof c === 'string' ? document.createTextNode(c) : c);
  return n;
}

function $id(id) { return document.getElementById(id); }

// ─── Toast notifications (reemplaza alert()) ─────────────────────────────────

function toast(msg, type = 'info', ms = 3800) {
  const container = $id('toast-container');
  if (!container) return;
  const t = el('div', { class: `toast toast-${type}` }, msg);
  container.appendChild(t);
  requestAnimationFrame(() => t.classList.add('show'));
  setTimeout(() => {
    t.classList.remove('show');
    setTimeout(() => t.remove(), 350);
  }, ms);
}

// ─── Modal genérico ──────────────────────────────────────────────────────────

function showModal(title, bodyNode, buttons = []) {
  closeModal();
  const backdrop = el('div', { class: 'modal-backdrop', id: 'modal_backdrop' });
  const closeBtn = el('button', { class: 'modal-close', onclick: closeModal }, '✕');
  const header   = el('div', { class: 'modal-header' }, el('h3', { class: 'modal-title' }, title), closeBtn);
  const body     = el('div', { class: 'modal-body' }, bodyNode);
  const footer   = el('div', { class: 'modal-footer' });
  for (const b of buttons) {
    const btn = el('button', { class: b.cls || 'btn btn-primary', onclick: () => b.action?.() }, b.label);
    footer.appendChild(btn);
  }
  const modal = el('div', { class: 'modal' }, header, body, footer);
  backdrop.appendChild(modal);
  document.body.appendChild(backdrop);
  // Cerrar al hacer clic fuera del modal
  backdrop.addEventListener('click', e => { if (e.target === backdrop) closeModal(); });
}

function closeModal() {
  $id('modal_backdrop')?.remove();
}

// ─── Confirmación con modal ───────────────────────────────────────────────────

function confirmModal(msg, onConfirm) {
  const body = el('p', { class: 'confirm-msg' }, msg);
  showModal('Confirmar acción', body, [
    { label: 'Cancelar', cls: 'btn btn-secondary', action: closeModal },
    { label: 'Confirmar', cls: 'btn btn-danger',   action: () => { closeModal(); onConfirm(); } },
  ]);
}

// ─── Tabs ────────────────────────────────────────────────────────────────────

const TABS = ['empleados', 'semana', 'convocatorias', 'sabados', 'estadisticas', 'config'];

function switchTab(tab) {
  for (const t of TABS) {
    const sec = $id('tab-' + t);
    if (sec) sec.style.display = t === tab ? '' : 'none';
  }
  document.querySelectorAll('.nav-tab').forEach(btn =>
    btn.classList.toggle('active', btn.dataset.tab === tab)
  );
  if (tab === 'semana') renderWeekPlanner();
}

// ─── Estado de UI local ──────────────────────────────────────────────────────

let empPage        = 1;
let empSearch      = '';
let empPageSz      = 10;
let startupAlerts  = []; // {type:'warning'|'danger', msg:string}
let weekPlannerKey = Models.getISOWeekKey(); // semana visible en el planificador

// ─── Montaje principal ────────────────────────────────────────────────────────

function mountUI() {
  const appRoot = $id('app');

  // Toast container
  const toastContainer = el('div', { id: 'toast-container', class: 'toast-container' });
  document.body.appendChild(toastContainer);

  // Header
  const header = el('header', { class: 'app-header' },
    el('div', { class: 'app-header-inner' },
      el('div', { class: 'app-brand' },
        el('img', { src: '/celsur-logo.png', alt: 'Celsur', class: 'app-logo-img',
          onerror: "this.style.display='none'" }),
        el('div', { class: 'app-brand-text' },
          el('span', { class: 'app-title' }, 'Extras Celsur'),
          el('span', { class: 'app-op' }, 'Op. Makro')
        )
      ),
      el('div', { id: 'shift-indicator', class: 'shift-badge' })
    )
  );

  // Nav tabs
  const tabLabels = {
    empleados:     '👥 Empleados',
    semana:        '📋 Semana',
    convocatorias: '📞 Convocatorias',
    sabados:       '📅 Sábados',
    estadisticas:  '📊 Estadísticas',
    config:        '⚙️ Config',
  };
  const nav = el('nav', { class: 'nav-tabs' });
  for (const t of TABS) {
    const btn = el('button', { class: 'nav-tab', 'data-tab': t, onclick: () => switchTab(t) }, tabLabels[t]);
    nav.appendChild(btn);
  }

  // Sections
  const sections = el('div', { class: 'tab-sections' },
    buildTabEmpleados(),
    buildTabSemana(),
    buildTabConvocatorias(),
    buildTabSabados(),
    buildTabEstadisticas(),
    buildTabConfig()
  );

  const alertBar = el('div', { id: 'alert-bar', class: 'alert-bar' });
  const footer = el('footer', { class: 'app-footer' }, 'creado por M. Zequeira');

  appRoot.innerHTML = '';
  appRoot.appendChild(header);
  appRoot.appendChild(nav);
  appRoot.appendChild(alertBar);
  appRoot.appendChild(sections);
  appRoot.appendChild(footer);

  switchTab('empleados');
  refreshShiftIndicator();
  renderEmployees();
}

function refreshShiftIndicator() {
  const cfg = Models.getSystemConfig();
  const el2 = $id('shift-indicator');
  if (el2) el2.textContent = 'Turno activo: ' + cfg.currentShiftWeek.toUpperCase();
}

function renderAlertBar() {
  const bar = $id('alert-bar');
  if (!bar) return;
  bar.innerHTML = '';
  startupAlerts.forEach((a, i) => {
    const item = el('div', { class: 'startup-alert startup-alert-' + a.type },
      el('span', { class: 'startup-alert-msg' }, a.msg),
      el('button', { class: 'alert-dismiss', title: 'Cerrar', onclick: () => {
        startupAlerts.splice(i, 1);
        renderAlertBar();
      }}, '✕')
    );
    bar.appendChild(item);
  });
}

// ─── Tab: Empleados ───────────────────────────────────────────────────────────

function buildTabEmpleados() {
  const sec = el('div', { id: 'tab-empleados', class: 'tab-section' });

  const toolbar = el('div', { class: 'toolbar' },
    el('input', {
      id: 'emp-search', type: 'text', class: 'input-search',
      placeholder: '🔍 Buscar por nombre o ID…',
      oninput: () => { empSearch = $id('emp-search').value.trim(); empPage = 1; renderEmployees(); }
    }),
    el('select', {
      id: 'emp-page-size', class: 'select-sm',
      onchange: () => { empPageSz = parseInt($id('emp-page-size').value); empPage = 1; renderEmployees(); }
    },
      el('option', { value: '5' }, '5'),
      el('option', { value: '10', selected: '' }, '10'),
      el('option', { value: '25' }, '25'),
      el('option', { value: '50' }, '50')
    ),
    el('button', { class: 'btn btn-primary', onclick: openAddEmployeeModal }, '+ Agregar empleado'),
    el('button', { class: 'btn btn-secondary', onclick: openImportCsvModal }, '⬆ Importar (CSV/XLS)')
  );

  const list = el('div', { id: 'employees-list' });

  sec.append(
    el('h2', { class: 'section-title' }, 'Empleados'),
    toolbar,
    list
  );
  return sec;
}

function renderEmployees() {
  const cont = $id('employees-list');
  if (!cont) return;
  cont.innerHTML = '';

  const all      = Models.listEmployees();
  const q        = empSearch.toLowerCase();
  const filtered = q
    ? all.filter(e => e.name.toLowerCase().includes(q) || e.id.includes(q))
    : all;

  if (!filtered.length) {
    cont.appendChild(el('div', { class: 'empty-state' }, 'No hay empleados coincidentes.'));
    return;
  }

  const totalPages = Math.max(1, Math.ceil(filtered.length / empPageSz));
  empPage = Math.min(Math.max(1, empPage), totalPages);
  const start = (empPage - 1) * empPageSz;
  const items = filtered.slice(start, start + empPageSz);

  const tbl = el('table', { class: 'data-table' });
  const avMap = Models.getWeekAvailability();
  tbl.appendChild(
    el('thead', {},
      el('tr', {},
        el('th', {}, 'ID'),
        el('th', {}, 'Nombre'),
        el('th', {}, 'Turno'),
        el('th', {}, 'Tipo'),
        el('th', {}, 'Reputación'),
        el('th', {}, 'Estado'),
        el('th', {}, 'Esta semana'),
        el('th', {}, 'Acciones')
      )
    )
  );

  const tbody = el('tbody');
  for (const e of items) {
    const repClass = e.reputation >= 80 ? 'rep-high' : e.reputation >= 50 ? 'rep-mid' : 'rep-low';
    const estadoBadge = e.activo
      ? el('span', { class: 'badge badge-success' }, 'Activo')
      : el('span', { class: 'badge badge-muted' }, 'Inactivo');
    const tr = el('tr', {},
      el('td', { class: 'mono' }, e.id),
      el('td', { class: 'bold' }, e.name),
      el('td', {}, e.turno_base),
      el('td', {}, el('span', { class: 'badge badge-type' }, e.tipo)),
      el('td', {}, el('span', { class: `rep-score ${repClass}` }, String(e.reputation))),
      el('td', {}, estadoBadge),
      el('td', {}, (() => {
        const av = avMap[e.id];
        if (!av || !av.disponible) return el('span', { class: 'badge badge-muted', title: 'Sin marcar para esta semana' }, '—');
        const diasLabel = (av.dias || []).map(d => d.slice(0, 2).toUpperCase()).join(' ');
        return el('span', { class: 'badge badge-success', title: 'Días: ' + (av.dias || []).join(', ') }, '✓ ' + diasLabel);
      })()),
      el('td', { class: 'actions' },
        el('button', { class: 'btn btn-sm btn-info',    onclick: () => showEmployeeDetailModal(e.id) }, 'Ver'),
        el('button', { class: 'btn btn-sm btn-primary', onclick: () => openCallModal(e.id)           }, '📞 Convocar'),
        el('button', { class: 'btn btn-sm btn-warning', onclick: () => openSaturdayModal(e.id)       }, '📅 Sábado'),
        el('button', { class: 'btn btn-sm btn-success', onclick: () => doRecordWeekdayExtra(e.id)    }, '+Extra')
      )
    );
    tbody.appendChild(tr);
  }
  tbl.appendChild(tbody);
  cont.appendChild(tbl);

  // Paginación
  const pag = el('div', { class: 'pagination' });
  const mkBtn = (label, page, disabled = false) => {
    const b = el('button', { class: 'page-btn' + (disabled ? ' disabled' : ''), onclick: () => { if (!disabled) { empPage = page; renderEmployees(); } } }, label);
    return b;
  };
  pag.append(
    mkBtn('«', 1, empPage === 1),
    mkBtn('‹', empPage - 1, empPage === 1),
    el('span', { class: 'page-info' }, `Página ${empPage} / ${totalPages}  (${filtered.length} empleados)`),
    mkBtn('›', empPage + 1, empPage === totalPages),
    mkBtn('»', totalPages, empPage === totalPages)
  );
  cont.appendChild(pag);
}

// ─── Tab: Semana ─────────────────────────────────────────────────────────────

function buildTabSemana() {
  const sec = el('div', { id: 'tab-semana', class: 'tab-section' });
  sec.appendChild(el('div', { id: 'week-planner-root' }));
  return sec;
}

function renderWeekPlanner() {
  const root = $id('week-planner-root');
  if (!root) return;
  root.innerHTML = '';

  const currentWeek  = Models.getISOWeekKey();
  const monday       = Models.getWeekMondayDate(weekPlannerKey);
  const friday       = new Date(monday); friday.setUTCDate(monday.getUTCDate() + 4);
  const fmtDay = d => d.toLocaleDateString('es-AR', { day: '2-digit', month: 'short', timeZone: 'UTC' });
  const isCurrentWeek = weekPlannerKey === currentWeek;

  const avMap = Models.getWeekAvailability(weekPlannerKey);
  const allEmps = Models.listEmployees().filter(e => e.activo);

  // ── Semana navigación ──
  const [, wNum] = weekPlannerKey.split('-W');
  const weekLabel = `Sem. ${wNum} · ${fmtDay(monday)} – ${fmtDay(friday)} ${monday.getUTCFullYear()}`;
  const isFuture = weekPlannerKey > currentWeek;

  const weekNav = el('div', { class: 'week-nav' },
    el('button', { class: 'btn btn-secondary btn-sm', onclick: () => {
      weekPlannerKey = Models.shiftWeekKey(weekPlannerKey, -1);
      renderWeekPlanner();
    }}, '‹ Anterior'),
    el('span', { class: 'week-nav-label' + (isCurrentWeek ? ' week-current' : isFuture ? ' week-future' : ' week-past') },
      weekLabel,
      isCurrentWeek ? el('span', { class: 'badge badge-success', style: 'margin-left:8px;font-size:10px' }, 'Semana actual') : el('span', {}),
      isFuture ? el('span', { class: 'badge badge-warning', style: 'margin-left:8px;font-size:10px' }, 'Próxima') : el('span', {})
    ),
    el('button', { class: 'btn btn-secondary btn-sm', onclick: () => {
      weekPlannerKey = Models.shiftWeekKey(weekPlannerKey, 1);
      renderWeekPlanner();
    }}, 'Siguiente ›'),
    el('button', { class: 'btn btn-primary btn-sm', onclick: () => {
      weekPlannerKey = Models.getISOWeekKey();
      renderWeekPlanner();
    }}, 'Hoy')
  );

  // ── Filtro turno ──
  let planFilter = '';
  const filterSel = el('select', { class: 'select-sm', onchange: e => { planFilter = e.target.value; redraw(); } },
    el('option', { value: '' }, 'Todos los turnos'),
    el('option', { value: 'mañana' }, 'Mañana'),
    el('option', { value: 'tarde' },  'Tarde')
  );

  // ── Acciones globales ──
  const btnMarkAll = el('button', { class: 'btn btn-success btn-sm', onclick: () => {
    const visible = planFilter ? allEmps.filter(e => e.turno_base === planFilter) : allEmps;
    const map = {};
    visible.forEach(e => {
      map[e.id] = { disponible: true, dias: Models.DIAS_HABILES.slice() };
    });
    Models.bulkSetWeekAvailability(map, weekPlannerKey);
    renderWeekPlanner();
    renderEmployees();
  }}, '✓ Marcar todos disponibles');

  const btnClear = el('button', { class: 'btn btn-danger btn-sm', onclick: () => {
    confirmModal('¿Limpiar toda la planificación de esta semana?', () => {
      Models.resetWeekAvailability(weekPlannerKey);
      renderWeekPlanner();
      renderEmployees();
      toast('Planificación de la semana limpiada.', 'info');
    });
  }}, '✗ Limpiar semana');

  const toolbar = el('div', { class: 'toolbar', style: 'margin-bottom:12px' },
    filterSel, btnMarkAll, btnClear
  );

  // ── Tabla de planificación ──
  const dias = Models.DIAS_HABILES;
  const diaLabel = { lunes: 'Lu', martes: 'Ma', miercoles: 'Mi', jueves: 'Ju', viernes: 'Vi' };

  const thead = el('thead', {},
    el('tr', {},
      el('th', {}, 'Legajo'),
      el('th', {}, 'Nombre'),
      el('th', {}, 'Turno'),
      el('th', {}, 'Puesto'),
      el('th', { class: 'text-center' }, '¿Disponible?'),
      ...dias.map(d => el('th', { class: 'text-center', title: d }, diaLabel[d]))
    )
  );

  const tbody = el('tbody');

  function buildRows(emps) {
    tbody.innerHTML = '';
    const toShow = planFilter ? emps.filter(e => e.turno_base === planFilter) : emps;
    if (!toShow.length) {
      tbody.appendChild(el('tr', {}, el('td', { colspan: '10', class: 'muted', style: 'text-align:center;padding:20px' }, 'Sin empleados activos.')));
      return;
    }
    for (const emp of toShow) {
      const av  = avMap[emp.id] || { disponible: false, dias: [] };
      const row = el('tr', { class: av.disponible ? 'week-row-avail' : '' });

      // ── Disponible checkbox ──
      const chkDisp = el('input', { type: 'checkbox', class: 'week-chk' });
      chkDisp.checked = !!av.disponible;
      chkDisp.addEventListener('change', () => {
        const existing = Object.assign({}, avMap[emp.id] || { disponible: false, dias: [] });
        existing.disponible = chkDisp.checked;
        if (existing.dias.length === 0 && chkDisp.checked) existing.dias = Models.DIAS_HABILES.slice();
        avMap[emp.id] = existing;
        Models.setWeekAvailability(emp.id, existing.disponible, existing.dias, weekPlannerKey);
        row.className = existing.disponible ? 'week-row-avail' : '';
        diaChks.forEach(dc => { dc.chk.disabled = !chkDisp.checked; });
        renderEmployees();
      });

      // ── Día checkboxes ──
      const diaChks = dias.map(d => {
        const chk = el('input', { type: 'checkbox', class: 'week-chk' });
        chk.checked = av.dias.includes(d);
        chk.disabled = !av.disponible;
        chk.addEventListener('change', () => {
          const existing = Object.assign({}, avMap[emp.id] || { disponible: false, dias: [] });
          if (chk.checked) { if (!existing.dias.includes(d)) existing.dias.push(d); }
          else { existing.dias = existing.dias.filter(x => x !== d); }
          avMap[emp.id] = existing;
          Models.setWeekAvailability(emp.id, existing.disponible, existing.dias, weekPlannerKey);
        });
        return { d, chk };
      });

      row.append(
        el('td', { class: 'mono small' }, emp.legajo || '—'),
        el('td', { class: 'bold' }, emp.name),
        el('td', {}, emp.turno_base),
        el('td', { class: 'muted small' }, emp.puesto || '—'),
        el('td', { class: 'text-center' }, chkDisp),
        ...diaChks.map(dc => el('td', { class: 'text-center' }, dc.chk))
      );
      tbody.appendChild(row);
    }
  }

  buildRows(allEmps);
  filterSel.addEventListener('change', () => buildRows(allEmps));

  function redraw() { buildRows(allEmps); }

  const tbl = el('table', { class: 'data-table week-plan-table' }, thead, tbody);

  // ── Resumen ──
  const dispCount = Object.values(avMap).filter(v => v.disponible).length;
  const summary = el('p', { class: 'muted', style: 'margin-top:10px;font-size:12px' },
    `${dispCount} empleado(s) marcados disponibles para esta semana de ${allEmps.length} activos.`
  );

  root.append(
    el('h2', { class: 'section-title' }, '📋 Planificación Semanal'),
    el('p', { class: 'section-desc' }, 'Marcá quién hace horas extras esta semana y en qué días se lo puede convocar. La selección es por semana y se limpia automáticamente.'),
    weekNav,
    el('div', { class: 'card', style: 'margin-top:14px' },
      toolbar,
      el('div', { class: 'table-scroll' }, tbl),
      summary
    )
  );
}

// ─── Modal: Agregar empleado ──────────────────────────────────────────────────

function openAddEmployeeModal() {
  const tipoSel = el('select', { id: 'fe-tipo', class: 'input-full' },
    el('option', { value: 'efectivo'         }, 'Efectivo'),
    el('option', { value: 'eventual_comun'   }, 'Eventual común'),
    el('option', { value: 'eventual_especial'}, 'Eventual especial')
  );

  const antContainer = el('div', { id: 'fe-ant-container', style: 'display:none' },
    formField('Antigüedad (meses)', el('input', { id: 'fe-ant-m', type: 'number', class: 'input-full', value: '0', min: '0', placeholder: 'Meses' })),
    formField('Antigüedad (años)',  el('input', { id: 'fe-ant-y', type: 'number', class: 'input-full', value: '0', min: '0', placeholder: 'Años' }))
  );

  const fechaContainer = el('div', { id: 'fe-fecha-container', style: 'display:none' },
    formField('Fecha fin contrato', el('input', { id: 'fe-fecha-fin', type: 'date', class: 'input-full' }))
  );

  function updateTipoVis() {
    const v = tipoSel.value;
    antContainer.style.display  = (v === 'eventual_comun' || v === 'eventual_especial') ? '' : 'none';
    fechaContainer.style.display = v === 'eventual_comun' ? '' : 'none';
  }
  tipoSel.addEventListener('change', updateTipoVis);

  const form = el('div', { class: 'form-grid' },
    formField('Nombre completo', el('input', { id: 'fe-name',     type: 'text', class: 'input-full', placeholder: 'Ej: Juan García' })),
    formField('N° de legajo (obligatorio para efectivos)', el('input', { id: 'fe-legajo',   type: 'text', class: 'input-full', placeholder: 'Ej: 1042' })),
    formField('Puesto', el('input', { id: 'fe-puesto',   type: 'text', class: 'input-full', placeholder: 'Ej: Operario despostada' })),
    formField('Teléfono',        el('input', { id: 'fe-telefono', type: 'text', class: 'input-full', placeholder: 'Ej: 11-1234-5678' })),
    formField('Turno base', el('select', { id: 'fe-turno', class: 'input-full' },
      el('option', { value: 'mañana' }, 'Mañana'),
      el('option', { value: 'tarde'  }, 'Tarde')
    )),
    formField('Tipo de empleado', tipoSel),
    antContainer,
    fechaContainer
  );

  showModal('Agregar empleado', form, [
    { label: 'Cancelar', cls: 'btn btn-secondary', action: closeModal },
    { label: 'Guardar',  cls: 'btn btn-primary',   action: submitAddEmployee },
  ]);
  setTimeout(() => $id('fe-name')?.focus(), 50);
}

function submitAddEmployee() {
  const name     = $id('fe-name').value.trim();
  const turno    = $id('fe-turno').value;
  const tipo     = $id('fe-tipo').value;
  const legajo   = ($id('fe-legajo')?.value   || '').trim();
  const puesto   = ($id('fe-puesto')?.value   || '').trim();
  const telefono = ($id('fe-telefono')?.value || '').trim();
  const meses    = tipo !== 'efectivo' ? (parseInt($id('fe-ant-m')?.value) || 0) : 0;
  const anios    = tipo !== 'efectivo' ? (parseInt($id('fe-ant-y')?.value) || 0) : 0;
  const ant      = meses + anios * 12;
  const fecha_fin = tipo === 'eventual_comun' ? ($id('fe-fecha-fin')?.value || null) : null;

  if (tipo === 'efectivo' && !legajo) {
    toast('El número de legajo es obligatorio para empleados efectivos.', 'error');
    return;
  }

  // Validar nombre duplicado
  if (name) {
    const dup = Models.listEmployees().find(e => e.name.toLowerCase() === name.toLowerCase());
    if (dup) {
      toast(`Ya existe un empleado con el nombre "${dup.name}" (ID: ${dup.id}).`, 'error');
      return;
    }
  }

  try {
    Models.initEmployee({ name, turno_base: turno, tipo, antiguedad_meses: ant, fecha_fin, telefono, legajo, puesto });
    closeModal();
    renderEmployees();
    toast(`Empleado "${name}" creado correctamente.`, 'success');
  } catch (e) {
    toast(e.message, 'error');
  }
}

// ─── Modal: Detalle de empleado ───────────────────────────────────────────────

function showEmployeeDetailModal(id) {
  const e = Models.getEmployee(id);
  if (!e) { toast('Empleado no encontrado', 'error'); return; }

  const stats = e.stats;
  const confiabilidad = stats.convocado > 0
    ? ((stats.acepto / stats.convocado) * 100).toFixed(1) + '%'
    : 'N/A';

  const body = el('div', { class: 'detail-grid' },
    el('div', { class: 'detail-section' },
      el('h4', {}, 'Datos personales'),
      infoRow('ID',      e.id),
      infoRow('Legajo',  e.legajo  || '—'),
      infoRow('Nombre',  e.name),
      infoRow('Puesto',  e.puesto  || '—'),
      infoRow('Turno base', e.turno_base),
      infoRow('Tipo',    e.tipo),
      infoRow('Teléfono', e.telefono || '—'),
      infoRow('Antigüedad', e.antiguedad_meses ? e.antiguedad_meses + ' meses' : '—'),
      infoRow('Fecha fin', e.fecha_fin || '—'),
      infoRow('Activo', e.activo ? 'Sí' : 'No'),
      infoRow('Reputación', e.reputation + ' / 100'),
    ),
    el('div', { class: 'detail-section' },
      el('h4', {}, 'Estadísticas acumulativas'),
      infoRow('Horas 50%',    stats.horas_50),
      infoRow('Horas 100%',   stats.horas_100),
      infoRow('Convocado',    stats.convocado),
      infoRow('Aceptó',       stats.acepto),
      infoRow('Rechazó',      stats.rechazo),
      infoRow('No respondió', stats.no_respondio),
      infoRow('Nro incorrecto', stats.numero_incorrecto),
      infoRow('Faltó',        stats.falto),
      infoRow('Sábados trab.', stats.sabados_trabajados),
      infoRow('Confiabilidad', confiabilidad),
    ),
    buildIncidentsList(e)
  );

  showModal('Detalle: ' + e.name, body, [
    { label: 'Editar',   cls: 'btn btn-secondary', action: () => openEditEmployeeModal(id) },
    { label: 'Reporte individual', cls: 'btn btn-info', action: () => generateEmployeePrintableReport(id) },
    { label: 'Cerrar',   cls: 'btn btn-primary',   action: closeModal },
  ]);
}

function buildIncidentsList(e) {
  const incidents = e.incidents || [];
  if (!incidents.length) return el('div', { class: 'detail-section' }, el('h4', {}, 'Incidentes'), el('p', { class: 'muted' }, 'Sin incidentes registrados.'));

  const rows = incidents.map(inc => {
    const statusBadge = inc.status === 'revertido'
      ? el('span', { class: 'badge badge-success' }, 'Revertido')
      : inc.status === 'rechazado'
      ? el('span', { class: 'badge badge-danger' }, 'Rechazado')
      : inc.status === 'cerrado_sin_descargo'
      ? el('span', { class: 'badge badge-muted' }, 'Sin descargo')
      : el('span', { class: 'badge badge-warning' }, 'Pendiente descargo');

    const actions = el('div', { class: 'incident-actions' });
    if (inc.status === 'pendiente_descargo') {
      if (!inc.descargo) {
        actions.appendChild(el('button', { class: 'btn btn-xs btn-warning', onclick: () => openDescargoModal(e.id, inc.id) }, 'Presentar descargo'));
      } else {
        actions.appendChild(el('button', { class: 'btn btn-xs btn-success', onclick: () => resolveDescargoModal(e.id, inc.id, true)  }, '✓ Aprobar'));
        actions.appendChild(el('button', { class: 'btn btn-xs btn-danger',  onclick: () => resolveDescargoModal(e.id, inc.id, false) }, '✗ Rechazar'));
      }
    }
    return el('div', { class: 'incident-row' },
      el('div', { class: 'incident-info' },
        el('span', { class: 'bold' }, inc.reason),
        el('span', { class: 'muted' }, ' | ' + new Date(inc.ts).toLocaleDateString()),
        el('span', { class: inc.delta < 0 ? 'text-danger' : 'text-success' }, ' ' + (inc.delta > 0 ? '+' : '') + inc.delta + ' pts'),
        inc.descargo ? el('span', { class: 'muted' }, ' | "' + inc.descargo.text + '"') : el('span', {})
      ),
      statusBadge,
      actions
    );
  });

  return el('div', { class: 'detail-section incidents-section' },
    el('h4', {}, 'Incidentes (' + incidents.length + ')'),
    ...rows
  );
}

function openDescargoModal(employeeId, incidentId) {
  const body = el('div', {},
    el('p', {}, 'Ingresá el texto del descargo del empleado:'),
    el('textarea', { id: 'descargo-text', class: 'textarea-full', rows: '4', placeholder: 'Descripción del descargo…' })
  );
  showModal('Presentar descargo', body, [
    { label: 'Cancelar', cls: 'btn btn-secondary', action: closeModal },
    {
      label: 'Enviar', cls: 'btn btn-primary', action: () => {
        const text = $id('descargo-text').value.trim();
        if (!text) { toast('El texto del descargo es requerido.', 'error'); return; }
        try {
          Models.submitDescargo(employeeId, incidentId, text);
          closeModal();
          toast('Descargo presentado correctamente.', 'success');
          showEmployeeDetailModal(employeeId);
        } catch (e) { toast(e.message, 'error'); }
      }
    },
  ]);
}

function resolveDescargoModal(employeeId, incidentId, approved) {
  confirmModal(
    approved ? '¿Aprobar el descargo? Esto revertirá la penalización.' : '¿Rechazar el descargo? La penalización se mantiene.',
    () => {
      try {
        Models.resolveDescargo(employeeId, incidentId, approved);
        toast(approved ? 'Descargo aprobado. Reputación restaurada.' : 'Descargo rechazado.', approved ? 'success' : 'warning');
        showEmployeeDetailModal(employeeId);
      } catch (e) { toast(e.message, 'error'); }
    }
  );
}

function openEditEmployeeModal(id) {
  const e = Models.getEmployee(id);
  if (!e) return;

  const tipoSel = el('select', { id: 'ee-tipo', class: 'input-full' },
    el('option', { value: 'efectivo',          ...(e.tipo === 'efectivo'          ? { selected: '' } : {}) }, 'Efectivo'),
    el('option', { value: 'eventual_comun',    ...(e.tipo === 'eventual_comun'    ? { selected: '' } : {}) }, 'Eventual común'),
    el('option', { value: 'eventual_especial', ...(e.tipo === 'eventual_especial' ? { selected: '' } : {}) }, 'Eventual especial')
  );

  const totalMeses = e.antiguedad_meses || 0;
  const antAnios   = Math.floor(totalMeses / 12);
  const antMeses   = totalMeses % 12;

  const antContainer = el('div', { id: 'ee-ant-container' },
    formField('Antigüedad (meses)', el('input', { id: 'ee-ant-m', type: 'number', class: 'input-full', value: String(antMeses), min: '0', placeholder: 'Meses' })),
    formField('Antigüedad (años)',  el('input', { id: 'ee-ant-y', type: 'number', class: 'input-full', value: String(antAnios), min: '0', placeholder: 'Años' }))
  );

  const fechaContainer = el('div', { id: 'ee-fecha-container' },
    formField('Fecha fin contrato', el('input', { id: 'ee-fecha-fin', type: 'date', class: 'input-full', value: e.fecha_fin || '' }))
  );

  function updateTipoVis() {
    const v = tipoSel.value;
    antContainer.style.display  = (v === 'eventual_comun' || v === 'eventual_especial') ? '' : 'none';
    fechaContainer.style.display = v === 'eventual_comun' ? '' : 'none';
  }
  tipoSel.addEventListener('change', updateTipoVis);
  updateTipoVis();

  const form = el('div', { class: 'form-grid' },
    formField('Nombre completo', el('input', { id: 'ee-name',     type: 'text', class: 'input-full', value: e.name })),
    formField('N° de legajo',    el('input', { id: 'ee-legajo',   type: 'text', class: 'input-full', value: e.legajo   || '' })),
    formField('Puesto',          el('input', { id: 'ee-puesto',   type: 'text', class: 'input-full', value: e.puesto   || '' })),
    formField('Teléfono',        el('input', { id: 'ee-telefono', type: 'text', class: 'input-full', value: e.telefono || '' })),
    formField('Turno base', el('select', { id: 'ee-turno', class: 'input-full' },
      el('option', { value: 'mañana', ...(e.turno_base === 'mañana' ? { selected: '' } : {}) }, 'Mañana'),
      el('option', { value: 'tarde',  ...(e.turno_base === 'tarde'  ? { selected: '' } : {}) }, 'Tarde')
    )),
    formField('Tipo de empleado', tipoSel),
    antContainer,
    fechaContainer,
    formField('Estado', el('select', { id: 'ee-activo', class: 'input-full' },
      el('option', { value: 'true',  ...(e.activo ? { selected: '' } : {}) }, 'Activo'),
      el('option', { value: 'false', ...(!e.activo ? { selected: '' } : {}) }, 'Inactivo')
    ))
  );

  showModal('Editar: ' + e.name, form, [
    { label: 'Cancelar', cls: 'btn btn-secondary', action: closeModal },
    {
      label: 'Guardar', cls: 'btn btn-primary', action: () => {
        const newTipo = $id('ee-tipo').value;
        const newMeses = newTipo !== 'efectivo' ? (parseInt($id('ee-ant-m').value) || 0) : 0;
        const newAnios = newTipo !== 'efectivo' ? (parseInt($id('ee-ant-y').value) || 0) : 0;
        try {
          Models.updateEmployee(id, {
            name:             $id('ee-name').value.trim() || e.name,
            legajo:           $id('ee-legajo').value.trim(),
            puesto:           $id('ee-puesto').value.trim(),
            telefono:         $id('ee-telefono').value.trim(),
            turno_base:       $id('ee-turno').value,
            tipo:             newTipo,
            antiguedad_meses: newMeses + newAnios * 12,
            fecha_fin:        newTipo === 'eventual_comun' ? ($id('ee-fecha-fin').value || null) : null,
            activo:           $id('ee-activo').value === 'true',
          });
          closeModal();
          renderEmployees();
          toast('Empleado actualizado.', 'success');
        } catch (e2) { toast(e2.message, 'error'); }
      }
    },
  ]);
}

// ─── Modal: Importar CSV / XLS / XLSX ───────────────────────────────────────

function openImportCsvModal() {
  const body = el('div', {},
    el('p', {}, 'Acepta archivos CSV, XLS o XLSX. Columnas: nombre, legajo, puesto, turno_base, tipo, antiguedad_meses, fecha_fin, telefono.'),
    el('input', { id: 'csv-file-input', type: 'file', accept: '.csv,.xls,.xlsx', class: 'input-full' })
  );
  showModal('Importar empleados', body, [
    { label: 'Cancelar', cls: 'btn btn-secondary', action: closeModal },
    { label: 'Importar', cls: 'btn btn-primary',   action: doImportCsv },
  ]);
}

function doImportCsv() {
  const file = $id('csv-file-input').files?.[0];
  if (!file) { toast('Seleccioná un archivo.', 'error'); return; }

  const ext = file.name.split('.').pop().toLowerCase();

  function processRows(rows) {
    let created = 0, errors = 0;
    for (const r of rows) {
      const name     = String(r.nombre || r.name || r.Nombre || r.NOMBRE || '').trim();
      const turno    = r.turno_base || r.turno || 'mañana';
      const tipo     = r.tipo || 'efectivo';
      const ant      = parseInt(r.antiguedad_meses || r.antiguedad || '0') || 0;
      const fecha_fin = r.fecha_fin || r.fechaFin || null;
      const telefono  = String(r.telefono || r.tel || '');
      const legajo    = String(r.legajo   || r.Legajo   || r.nro_legajo || '');
      const puesto    = String(r.puesto   || r.Puesto   || r.cargo       || '');
      if (!name) continue;
      try { Models.initEmployee({ name, turno_base: turno, tipo, antiguedad_meses: ant, fecha_fin, telefono, legajo, puesto }); created++; }
      catch { errors++; }
    }
    closeModal();
    renderEmployees();
    toast(`Importación completa: ${created} creados${errors ? ', ' + errors + ' errores' : ''}.`, errors ? 'warning' : 'success');
  }

  if (ext === 'csv') {
    const reader = new FileReader();
    reader.onload = () => {
      try { processRows(parseCSV(reader.result)); }
      catch (e) { toast('Error leyendo el CSV: ' + e.message, 'error'); }
    };
    reader.readAsText(file, 'UTF-8');
  } else if (ext === 'xls' || ext === 'xlsx') {
    if (!window.XLSX) { toast('Librería XLS no disponible (requiere conexión para la primera carga). Intentá con CSV.', 'error'); return; }
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const wb    = window.XLSX.read(ev.target.result, { type: 'array' });
        const sheet = wb.Sheets[wb.SheetNames[0]];
        const rows  = window.XLSX.utils.sheet_to_json(sheet, { defval: '' });
        processRows(rows);
      } catch (e) { toast('Error leyendo el archivo: ' + e.message, 'error'); }
    };
    reader.readAsArrayBuffer(file);
  } else {
    toast('Formato no soportado. Usá CSV, XLS o XLSX.', 'error');
  }
}

// ─── Tab: Convocatorias ───────────────────────────────────────────────────────

function buildTabConvocatorias() {
  const sec = el('div', { id: 'tab-convocatorias', class: 'tab-section' });
  sec.append(
    el('h2', { class: 'section-title' }, 'Convocatorias'),
    el('p', { class: 'section-desc' }, 'Para iniciar una convocatoria, seleccioná un empleado desde la pestaña Empleados y hacé clic en "📞 Convocar".'),
    el('div', { id: 'call-history-list' })
  );
  renderCallHistory();
  return sec;
}

function renderCallHistory() {
  const cont = $id('call-history-list');
  if (!cont) return;
  cont.innerHTML = '';
  const state  = Models.exportState();
  const calls  = Object.values(state.callEvents || {});
  if (!calls.length) { cont.appendChild(el('div', { class: 'empty-state' }, 'No hay convocatorias registradas.')); return; }

  const sorted = [...calls].sort((a, b) => b.timestamp?.localeCompare(a.timestamp));
  const tbl = el('table', { class: 'data-table' });
  tbl.appendChild(el('thead', {}, el('tr', {},
    el('th', {}, 'Empleado'), el('th', {}, 'Puesto'), el('th', {}, 'Fecha'), el('th', {}, 'Tipo extra'),
    el('th', {}, 'Intentos'), el('th', {}, 'Resultado'), el('th', {}, 'Acciones')
  )));
  const tbody = el('tbody');
  for (const c of sorted.slice(0, 100)) {
    const emp = state.employees[c.empleado_id];
    const resultBadge = c.resultado_final
      ? el('span', { class: `badge ${c.resultado_final === 'confirmado' ? 'badge-success' : 'badge-danger'}` }, c.resultado_final)
      : el('span', { class: 'badge badge-warning' }, 'Pendiente');
    tbody.appendChild(el('tr', {},
      el('td', {}, emp ? emp.name : c.empleado_id),
      el('td', { class: 'muted' }, emp?.puesto || '—'),
      el('td', {}, c.fecha || '—'),
      el('td', {}, c.tipo_extra || '—'),
      el('td', {}, String(c.attempts?.length || 0) + ' / 2'),
      el('td', {}, resultBadge),
      el('td', { class: 'actions' },
        !c.resultado_final
          ? el('button', { class: 'btn btn-sm btn-primary', onclick: () => openAttemptModal(c.id) }, 'Registrar intento')
          : el('span', { class: 'muted' }, 'Cerrada')
      )
    ));
  }
  tbl.appendChild(tbody);
  cont.appendChild(tbl);
}

function openCallModal(employeeId) {
  const e = Models.getEmployee(employeeId);
  if (!e) { toast('Empleado no encontrado', 'error'); return; }
  const today = new Date().toISOString().slice(0, 10);
  const body = el('div', { class: 'form-grid' },
    el('p', { class: 'bold' }, 'Empleado: ' + e.name),
    e.puesto ? el('p', { class: 'muted' }, 'Puesto: ' + e.puesto) : el('span', {}),
    e.legajo ? el('p', { class: 'muted' }, 'Legajo: ' + e.legajo) : el('span', {}),
    (() => {
      const av = Models.getWeekAvailability()[e.id];
      if (!av || !av.disponible) {
        return el('div', { class: 'startup-alert startup-alert-warning', style: 'margin-bottom:4px' },
          el('span', { class: 'startup-alert-msg' }, '⚠️ Este empleado no está marcado como disponible esta semana. Podes convocarlo igual.'));
      }
      const dias = (av.dias || []).join(', ');
      return el('div', { class: 'startup-alert startup-alert-warning', style: 'background:#f0fdf4;border-color:#86efac;color:#166534;margin-bottom:4px' },
        el('span', { class: 'startup-alert-msg' }, '✅ Disponible esta semana. Días habilitados: ' + (dias || 'no especificados')));
    })(),
    formField('Fecha', el('input', { id: 'call-fecha', type: 'date', class: 'input-full', value: today })),
    formField('Tipo de extra', el('input', { id: 'call-tipo', type: 'text', class: 'input-full', placeholder: 'Ej: turno tarde, guardia…' })),
    formField('Supervisor ID', el('input', { id: 'call-sup', type: 'text', class: 'input-full', placeholder: 'ID o nombre del supervisor' }))
  );
  showModal('Nueva convocatoria — ' + e.name, body, [
    { label: 'Cancelar', cls: 'btn btn-secondary', action: closeModal },
    {
      label: 'Crear y registrar intento', cls: 'btn btn-primary', action: () => {
        const fecha = $id('call-fecha').value;
        const tipo  = $id('call-tipo').value.trim();
        const sup   = $id('call-sup').value.trim();
        if (!fecha || !tipo) { toast('Fecha y tipo de extra son requeridos.', 'error'); return; }
        try {
          const ev = Models.createCallEvent({ empleado_id: employeeId, fecha, tipo_extra: tipo, supervisor_id: sup || null });
          closeModal();
          switchTab('convocatorias');
          renderCallHistory();
          toast('Convocatoria creada. Registrá el primer intento.', 'info');
          openAttemptModal(ev.id);
        } catch (e2) { toast(e2.message, 'error'); }
      }
    },
  ]);
}

function openAttemptModal(callId) {
  const state = Models.exportState();
  const call  = state.callEvents?.[callId];
  if (!call) { toast('Convocatoria no encontrada', 'error'); return; }
  const emp_2    = state.employees?.[call.empleado_id];
  const nIntento = (call.attempts?.length || 0) + 1;

  const body = el('div', { class: 'form-grid' },
    el('p', {}, el('strong', {}, 'Empleado: '), emp_2?.name || call.empleado_id),
    emp_2?.puesto ? el('p', { class: 'muted' }, 'Puesto: ' + emp_2.puesto) : el('span', {}),
    el('p', {}, el('strong', {}, 'Intento #' + nIntento + ' de ' + (Models.exportState ? '2' : '2'))),
    formField('Resultado del intento',
      el('select', { id: 'attempt-status', class: 'input-full' },
        el('option', { value: '' }, '— Seleccioná un estado —'),
        el('option', { value: 'confirmado' }, '✅ Confirmado'),
        el('option', { value: 'rechazo' }, '❌ Rechazó'),
        el('option', { value: 'no_respondio' }, '📵 No respondió'),
        el('option', { value: 'numero_incorrecto' }, '⚠️ Número incorrecto'),
        el('option', { value: 'atendio_otro' }, '👤 Atendió otro'),
        el('option', { value: 'falto' }, '🚫 Faltó')
      )
    ),
    formField('Nota (opcional)', el('input', { id: 'attempt-note', type: 'text', class: 'input-full', placeholder: 'Observación' }))
  );

  showModal('Registrar intento — Convocatoria', body, [
    { label: 'Cancelar', cls: 'btn btn-secondary', action: closeModal },
    {
      label: 'Guardar intento', cls: 'btn btn-primary', action: () => {
        const status = $id('attempt-status').value;
        const note   = $id('attempt-note').value.trim();
        if (!status) { toast('Seleccioná un estado.', 'error'); return; }
        try {
          const ev = Models.addCallAttempt(callId, { status, note });
          closeModal();
          renderCallHistory();
          renderEmployees();
          if (ev.resultado_final) {
            toast(`Convocatoria cerrada. Resultado: ${ev.resultado_final}`, ev.resultado_final === 'confirmado' ? 'success' : 'warning');
          } else {
            toast('Intento registrado. Podés agregar un segundo intento.', 'info');
          }
        } catch (e) { toast(e.message, 'error'); }
      }
    },
  ]);
}

// ─── Tab: Sábados ─────────────────────────────────────────────────────────────

// --- Tab: Sabados -----------------------------------------------------------

let satMgmtDate = '';

function buildTabSabados() {
  const today = new Date();
  const dow = today.getDay();
  const daysToSat = dow === 6 ? 0 : (6 - dow);
  const sat = new Date(today);
  sat.setDate(today.getDate() + daysToSat);
  const defaultDateStr = sat.toISOString().slice(0, 10);
  satMgmtDate = defaultDateStr.replace(/-/g, '_');

  const sec = el('div', { id: 'tab-sabados', class: 'tab-section' });
  sec.append(
    el('h2', { class: 'section-title' }, 'Sabados'),
    el('p', { class: 'section-desc' }, 'Flujo completo: intenciones (viernes)  asignacion (supervisor)  registro de horas (sabado).'),
    el('div', { class: 'card config-card' },
      el('h3', {}, 'Seleccionar sabado a gestionar'),
      el('div', { class: 'toolbar' },
        el('input', {
          id: 'sat-mgmt-date', type: 'date', class: 'input-sm',
          value: defaultDateStr,
          oninput: () => {
            const v = $id('sat-mgmt-date').value;
            if (v) { satMgmtDate = v.replace(/-/g, '_'); renderSaturdayMgmt(); }
          }
        }),
        el('button', { class: 'btn btn-primary', onclick: renderSaturdayMgmt }, 'Ver')
      )
    ),
    el('div', { id: 'sat-mgmt-panel' }),
    el('h3', { class: 'section-subtitle' }, 'Historial de sabados registrados'),
    el('div', { class: 'card' },
      el('button', { class: 'btn btn-secondary', onclick: renderSaturdayList }, 'Actualizar'),
      el('div', { id: 'saturday-list' })
    )
  );
  renderSaturdayMgmt();
  renderSaturdayList();
  return sec;
}

function renderSaturdayMgmt() {
  const cont = $id('sat-mgmt-panel');
  if (!cont) return;
  cont.innerHTML = '';
  if (!satMgmtDate) return;

  const state = Models.exportState();
  const ev = state.saturdayEvents?.[satMgmtDate] || { intentions: [], assignedEmployees: [], records: [] };
  ev.assignedEmployees = ev.assignedEmployees || [];
  const emps = state.employees;
  const dateLabel = satMgmtDate.replace(/_/g, '-');

  // --- FASE 1: Intenciones ---
  const intentList = el('div', { class: 'sat-phase-list' });
  const intentions = ev.intentions || [];
  if (!intentions.length) {
    intentList.appendChild(el('p', { class: 'muted' }, 'Nadie manifesto intencion aun.'));
  } else {
    intentions.forEach(i => {
      const emp = emps[i.employeeId];
      intentList.appendChild(el('div', { class: 'phase-item' },
        el('span', { class: 'phase-item-name' }, emp ? emp.name : i.employeeId),
        el('span', { class: 'muted small' }, new Date(i.ts).toLocaleDateString('es-AR')),
        el('button', { class: 'btn btn-xs btn-danger', onclick: () => {
          Models.removeSaturdayIntention(satMgmtDate, i.employeeId);
          renderSaturdayMgmt();
        }}, 'X')
      ));
    });
  }
  const fase1 = el('div', { class: 'card sat-phase' },
    el('h4', { class: 'phase-title phase-1' }, '1. Intenciones'),
    el('p', { class: 'muted small' }, 'Empleados que quieren trabajar el ' + dateLabel + '.'),
    intentList,
    el('button', { class: 'btn btn-primary btn-sm', onclick: () => openAddIntentionModal(satMgmtDate) }, '+ Agregar intencion')
  );

  // --- FASE 2: Asignados ---
  const assigned = ev.assignedEmployees;
  const assignList = el('div', { class: 'sat-phase-list' });
  if (!assigned.length) {
    assignList.appendChild(el('p', { class: 'muted' }, 'Nadie asignado aun.'));
  } else {
    assigned.forEach(a => {
      const emp = emps[a.employeeId];
      assignList.appendChild(el('div', { class: 'phase-item' },
        el('span', { class: 'phase-item-name' }, emp ? emp.name : a.employeeId),
        el('span', { class: 'muted small' }, 'Sup: ' + (a.supervisorId || '')),
        el('button', { class: 'btn btn-xs btn-danger', onclick: () => {
          Models.removeAssignmentFromSaturday(satMgmtDate, a.employeeId);
          renderSaturdayMgmt();
        }}, 'X')
      ));
    });
  }
  const assignActions = el('div', { class: 'toolbar' },
    el('button', { class: 'btn btn-primary btn-sm', onclick: () => openAddAssignmentModal(satMgmtDate) }, '+ Asignar empleado')
  );
  if (intentions.length) {
    assignActions.appendChild(
      el('button', { class: 'btn btn-secondary btn-sm', onclick: () => openAssignIntendingModal(satMgmtDate, intentions) }, 'Asignar desde intenciones (' + intentions.length + ')')
    );
  }
  const fase2 = el('div', { class: 'card sat-phase' },
    el('h4', { class: 'phase-title phase-2' }, '2. Asignacion'),
    el('p', { class: 'muted small' }, 'Empleados formalmente asignados para ese sabado.'),
    assignList,
    assignActions
  );

  // --- FASE 3: Horas registradas ---
  const records = ev.records || [];
  const registeredIds = new Set(records.map(r => r.employeeId));
  const recList = el('div', { class: 'sat-phase-list' });
  if (!records.length) {
    recList.appendChild(el('p', { class: 'muted' }, 'Sin horas registradas.'));
  } else {
    records.forEach(r => {
      const emp = emps[r.employeeId];
      recList.appendChild(el('div', { class: 'phase-item' },
        el('span', { class: 'phase-item-name' }, emp ? emp.name : r.employeeId),
        el('span', { class: 'badge badge-success' }, r.hours + ' h')
      ));
    });
  }
  // Asignados sin horas aun
  const pendingHours = assigned.filter(a => !registeredIds.has(a.employeeId));
  if (pendingHours.length) {
    recList.appendChild(el('p', { class: 'muted small' }, 'Pendientes de registrar:'));
    pendingHours.forEach(a => {
      const emp = emps[a.employeeId];
      recList.appendChild(el('div', { class: 'phase-item' },
        el('span', { class: 'phase-item-name' }, (emp ? emp.name : a.employeeId) + ' (pendiente)'),
        el('button', { class: 'btn btn-xs btn-success', onclick: () => openSaturdayHoursModal(a.employeeId, satMgmtDate) }, 'Registrar horas')
      ));
    });
  }
  const fase3 = el('div', { class: 'card sat-phase' },
    el('h4', { class: 'phase-title phase-3' }, '3. Horas registradas'),
    el('p', { class: 'muted small' }, 'Horas efectivamente trabajadas.'),
    recList,
    el('button', { class: 'btn btn-secondary btn-sm', onclick: () => openSaturdayHoursModal(null, satMgmtDate) }, '+ Registrar horas (otro empleado)')
  );

  cont.appendChild(el('div', { class: 'sat-phases' }, fase1, fase2, fase3));
}

function openAddIntentionModal(dateKey) {
  const emps = Models.listEmployees().filter(e => e.activo);
  if (!emps.length) { toast('No hay empleados activos.', 'error'); return; }
  const sel = el('select', { id: 'int-emp', class: 'input-full' },
    ...emps.map(e => el('option', { value: e.id }, e.name + ' (' + e.turno_base + ')'))
  );
  showModal('Registrar intencion de sabado', el('div', { class: 'form-grid' }, formField('Empleado', sel)), [
    { label: 'Cancelar', cls: 'btn btn-secondary', action: closeModal },
    { label: 'Registrar', cls: 'btn btn-primary', action: () => {
      try {
        Models.addSaturdayIntention(dateKey, $id('int-emp').value);
        closeModal(); renderSaturdayMgmt();
        toast('Intencion registrada.', 'success');
      } catch (e) { toast(e.message, 'error'); }
    }},
  ]);
}

function openAddAssignmentModal(dateKey) {
  const emps = Models.listEmployees().filter(e => e.activo);
  if (!emps.length) { toast('No hay empleados activos.', 'error'); return; }
  const sel = el('select', { id: 'asgn-emp', class: 'input-full' },
    ...emps.map(e => el('option', { value: e.id }, e.name + ' (' + e.turno_base + ')'))
  );
  const body = el('div', { class: 'form-grid' },
    formField('Empleado a asignar', sel),
    formField('Supervisor ID', el('input', { id: 'asgn-sup', type: 'text', class: 'input-full', placeholder: 'ID o nombre del supervisor' }))
  );
  showModal('Asignar empleado al sabado', body, [
    { label: 'Cancelar', cls: 'btn btn-secondary', action: closeModal },
    { label: 'Asignar', cls: 'btn btn-primary', action: () => {
      const supId = $id('asgn-sup').value.trim();
      if (!supId) { toast('Supervisor requerido.', 'error'); return; }
      try {
        Models.assignEmployeeToSaturday(dateKey, $id('asgn-emp').value, supId);
        closeModal(); renderSaturdayMgmt();
        toast('Asignacion registrada.', 'success');
      } catch (e) { toast(e.message, 'error'); }
    }},
  ]);
}

function openAssignIntendingModal(dateKey, intentions) {
  const body = el('div', { class: 'form-grid' },
    el('p', {}, 'Se asignaran los ' + intentions.length + ' empleados que manifestaron intencion.'),
    formField('Supervisor ID', el('input', { id: 'asgn-all-sup', type: 'text', class: 'input-full', placeholder: 'ID o nombre del supervisor' }))
  );
  showModal('Asignar todos los que manifestaron intencion', body, [
    { label: 'Cancelar', cls: 'btn btn-secondary', action: closeModal },
    { label: 'Asignar todos', cls: 'btn btn-warning', action: () => {
      const supId = $id('asgn-all-sup').value.trim();
      if (!supId) { toast('Supervisor requerido.', 'error'); return; }
      let ok = 0, skip = 0;
      for (const i of intentions) {
        try { Models.assignEmployeeToSaturday(dateKey, i.employeeId, supId); ok++; }
        catch (_) { skip++; }
      }
      closeModal(); renderSaturdayMgmt();
      toast('Asignados: ' + ok + (skip ? ' (' + skip + ' ya estaban asignados)' : '') + '.', 'success');
    }},
  ]);
}

function openSaturdayHoursModal(employeeId, dateKey) {
  const emps = Models.listEmployees().filter(e => e.activo);
  const empNode = employeeId
    ? el('p', {}, el('strong', {}, Models.getEmployee(employeeId)?.name || employeeId))
    : el('select', { id: 'sat-hrs-emp', class: 'input-full' },
        ...emps.map(e => el('option', { value: e.id }, e.name + ' (' + e.turno_base + ')'))
      );
  const body = el('div', { class: 'form-grid' },
    formField('Empleado', empNode),
    formField('Horas trabajadas', el('input', { id: 'sat-hrs-val', type: 'number', class: 'input-full', value: '4', min: '0.5', step: '0.5' }))
  );
  showModal('Registrar horas de sabado', body, [
    { label: 'Cancelar', cls: 'btn btn-secondary', action: closeModal },
    { label: 'Registrar', cls: 'btn btn-success', action: () => {
      const empId = employeeId || $id('sat-hrs-emp')?.value;
      const hours = parseFloat($id('sat-hrs-val').value);
      if (!empId || !hours || hours <= 0) { toast('Completa todos los campos.', 'error'); return; }
      try {
        Models.recordSaturdayWorked(empId, dateKey, hours);
        closeModal(); renderSaturdayMgmt(); renderSaturdayList();
        const emp = Models.getEmployee(empId);
        toast('Horas registradas: ' + hours + 'h para ' + (emp?.name || empId) + '.', 'success');
      } catch (e) { toast(e.message, 'error'); }
    }},
  ]);
}

function renderSaturdayList() {
  const cont = $id('saturday-list');
  if (!cont) return;
  cont.innerHTML = '';
  const state = Models.exportState();
  const keys = Object.keys(state.saturdayEvents || {}).sort().reverse();
  if (!keys.length) { cont.appendChild(el('div', { class: 'empty-state' }, 'No hay eventos de sabado registrados.')); return; }
  const tbl = el('table', { class: 'data-table' });
  tbl.appendChild(el('thead', {}, el('tr', {},
    el('th', {}, 'Fecha'), el('th', {}, 'Intenciones'), el('th', {}, 'Asignados'), el('th', {}, 'Registros'), el('th', {}, 'Total horas'), el('th', {}, 'Accion')
  )));
  const tbody = el('tbody');
  for (const key of keys.slice(0, 60)) {
    const ev = state.saturdayEvents[key];
    const totalHs = (ev.records || []).reduce((s, r) => s + (r.hours || 0), 0);
    tbody.appendChild(el('tr', {},
      el('td', { class: 'mono' }, key.replace(/_/g, '-')),
      el('td', {}, String((ev.intentions || []).length)),
      el('td', {}, String((ev.assignedEmployees || []).length)),
      el('td', {}, String((ev.records || []).length)),
      el('td', {}, totalHs.toFixed(1) + ' h'),
      el('td', {}, el('button', { class: 'btn btn-xs btn-secondary', onclick: () => {
        const dateInput = $id('sat-mgmt-date');
        if (dateInput) dateInput.value = key.replace(/_/g, '-');
        satMgmtDate = key;
        renderSaturdayMgmt();
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }}, 'Gestionar'))
    ));
  }
  tbl.appendChild(tbody);
  cont.appendChild(tbl);
}

function doRecordWeekdayExtra(employeeId) {
  const e = Models.getEmployee(employeeId);
  if (!e) return;
  const tipo = e.turno_base === 'mañana' ? '+3 horas 50%' : '+3 horas 100%';
  confirmModal(`¿Registrar extra día hábil para ${e.name}? (${tipo})`, () => {
    try {
      Models.recordWeekdayExtra(employeeId);
      renderEmployees();
      toast(`Extra registrada para ${e.name}: ${tipo}`, 'success');
    } catch (err) { toast(err.message, 'error'); }
  });
}

// ─── Tab: Estadísticas ────────────────────────────────────────────────────────

function buildTabEstadisticas() {
  const sec = el('div', { id: 'tab-estadisticas', class: 'tab-section' });
  sec.append(
    el('h2', { class: 'section-title' }, 'Estadísticas & Ranking'),
    el('div', { class: 'toolbar' },
      el('button', { class: 'btn btn-primary', onclick: renderStats }, '🔄 Actualizar'),
      el('button', { class: 'btn btn-secondary', onclick: doExportSuggestionsCsv }, '⬇ Exportar CSV ranking')
    ),
    el('div', { id: 'stats-summary', class: 'stats-cards' }),
    el('div', { id: 'stats-ranking' }),
    el('h3', { class: 'section-subtitle' }, 'Top incumplidores'),
    el('div', { id: 'stats-offenders' }),
    el('h3', { class: 'section-subtitle' }, 'Audit log — asignaciones fuera del top sugerido'),
    el('div', { id: 'stats-auditlog' })
  );
  renderStats();
  return sec;
}

function renderStats() {
  renderSummaryCards();
  renderRankingTable();
  renderTopOffenders();
  renderAuditLogs();
}

function renderSummaryCards() {
  const cont = $id('stats-summary');
  if (!cont) return;
  cont.innerHTML = '';
  const all    = Models.listEmployees();
  const active = all.filter(e => e.activo);
  const total50  = active.reduce((s, e) => s + e.stats.horas_50, 0);
  const total100 = active.reduce((s, e) => s + e.stats.horas_100, 0);
  const avgRep   = active.length ? (active.reduce((s, e) => s + e.reputation, 0) / active.length).toFixed(1) : '—';

  const cards = [
    { label: 'Empleados activos', value: active.length,        icon: '👥' },
    { label: 'Total horas 50%',   value: total50,              icon: '⏱' },
    { label: 'Total horas 100%',  value: total100,             icon: '⏱' },
    { label: 'Reputación promedio', value: avgRep + ' / 100',  icon: '⭐' },
  ];
  for (const c of cards) {
    cont.appendChild(el('div', { class: 'stat-card' },
      el('div', { class: 'stat-icon' }, c.icon),
      el('div', { class: 'stat-value' }, String(c.value)),
      el('div', { class: 'stat-label' }, c.label)
    ));
  }
}

function renderRankingTable() {
  const cont = $id('stats-ranking');
  if (!cont) return;
  cont.innerHTML = '';
  const list = Models.suggestionList();
  if (!list.length) { cont.appendChild(el('div', { class: 'empty-state' }, 'No hay empleados activos.')); return; }

  const tbl = el('table', { class: 'data-table' });
  tbl.appendChild(el('thead', {}, el('tr', {},
    el('th', {}, '#'), el('th', {}, 'Nombre'), el('th', {}, 'Turno'),
    el('th', {}, 'Score ↑'), el('th', {}, 'Horas tot.'),
    el('th', {}, 'Convocado'), el('th', {}, 'Confiabilidad'), el('th', {}, 'Reputación'),
    el('th', {}, 'Acciones')
  )));
  const tbody = el('tbody');
  list.forEach((e, idx) => {
    const m = e.__meta;
    const topBadge = idx < 3 ? el('span', { class: 'badge badge-top' }, ['🥇','🥈','🥉'][idx]) : el('span', {}, String(idx + 1));
    tbody.appendChild(el('tr', {},
      el('td', {}, topBadge),
      el('td', { class: 'bold' }, e.name),
      el('td', {}, e.turno_base),
      el('td', { class: 'mono' }, m.score.toFixed(2)),
      el('td', {}, String(m.total_horas)),
      el('td', {}, String(m.convocado)),
      el('td', {}, (m.confiabilidad * 100).toFixed(0) + '%'),
      el('td', {}, el('span', { class: `rep-score ${e.reputation >= 80 ? 'rep-high' : e.reputation >= 50 ? 'rep-mid' : 'rep-low'}` }, String(e.reputation))),
      el('td', { class: 'actions' },
        el('button', { class: 'btn btn-sm btn-primary', onclick: () => openAssignModal(e.id, list.slice(0, 10).map(x => x.id)) }, 'Asignar')
      )
    ));
  });
  tbl.appendChild(tbody);
  cont.appendChild(tbl);
}

function renderTopOffenders() {
  const cont = $id('stats-offenders');
  if (!cont) return;
  cont.innerHTML = '';
  const all = Models.listEmployees();
  const sorted = all
    .map(e => ({ ...e, _total: (e.stats.falto || 0) + (e.stats.no_respondio || 0) + (e.stats.numero_incorrecto || 0) + (e.stats.rechazo || 0) }))
    .filter(e => e._total > 0)
    .sort((a, b) => b._total - a._total)
    .slice(0, 10);

  if (!sorted.length) {
    cont.appendChild(el('p', { class: 'muted' }, 'Sin incumplimientos registrados.'));
    return;
  }

  const tbl = el('table', { class: 'data-table' });
  tbl.appendChild(el('thead', {}, el('tr', {},
    el('th', {}, 'Nombre'), el('th', {}, 'Faltó'), el('th', {}, 'No respondió'),
    el('th', {}, 'Nro incorrecto'), el('th', {}, 'Rechazó'),
    el('th', {}, 'Reputación'), el('th', {}, 'Total incump.')
  )));
  const tbody = el('tbody');
  sorted.forEach(e => {
    tbody.appendChild(el('tr', {},
      el('td', { class: 'bold' }, e.name),
      el('td', {}, String(e.stats.falto || 0)),
      el('td', {}, String(e.stats.no_respondio || 0)),
      el('td', {}, String(e.stats.numero_incorrecto || 0)),
      el('td', {}, String(e.stats.rechazo || 0)),
      el('td', {}, el('span', { class: `rep-score ${e.reputation >= 80 ? 'rep-high' : e.reputation >= 50 ? 'rep-mid' : 'rep-low'}` }, String(e.reputation))),
      el('td', { class: 'bold' }, String(e._total))
    ));
  });
  tbl.appendChild(tbody);
  cont.appendChild(tbl);
}

function renderAuditLogs() {
  const cont = $id('stats-auditlog');
  if (!cont) return;
  cont.innerHTML = '';
  const logs = Models.getAuditLogs();
  if (!logs.length) {
    cont.appendChild(el('p', { class: 'muted' }, 'Sin registros de auditoría.'));
    return;
  }
  const tbl = el('table', { class: 'data-table' });
  tbl.appendChild(el('thead', {}, el('tr', {},
    el('th', {}, 'Fecha'), el('th', {}, 'Supervisor'), el('th', {}, 'Empleado asignado'),
    el('th', {}, 'Motivo'), el('th', {}, 'Detalle')
  )));
  const tbody = el('tbody');
  logs.forEach(log => {
    const emp = Models.getEmployee(log.chosen_employee);
    tbody.appendChild(el('tr', {},
      el('td', { class: 'mono' }, new Date(log.ts).toLocaleDateString('es-AR')),
      el('td', {}, log.supervisor_id || '—'),
      el('td', {}, emp ? emp.name : log.chosen_employee),
      el('td', {}, log.reason),
      el('td', {}, log.note || '—')
    ));
  });
  tbl.appendChild(tbody);
  cont.appendChild(tbl);
}

function openAssignModal(chosenId, topIds) {
  const isInTop = topIds.includes(chosenId);
  if (isInTop) {
    confirmModal('¿Confirmar asignación de este empleado?', () => {
      toast('Empleado asignado.', 'success');
    });
    return;
  }
  // Fuera del top: pedir motivo para audit log
  const body = el('div', { class: 'form-grid' },
    el('p', { class: 'alert-warning' }, '⚠️ Este empleado está fuera del top sugerido. Es obligatorio registrar el motivo.'),
    formField('Supervisor ID', el('input', { id: 'assign-sup', type: 'text', class: 'input-full' })),
    formField('Motivo',
      el('select', { id: 'assign-reason', class: 'input-full' },
        el('option', { value: '' }, '— Seleccioná motivo —'),
        el('option', { value: 'urgencia_operativa'    }, 'Urgencia operativa'),
        el('option', { value: 'experiencia_requerida' }, 'Experiencia requerida'),
        el('option', { value: 'rotacion_excepcional'  }, 'Rotación excepcional'),
        el('option', { value: 'otro'                  }, 'Otro')
      )
    ),
    formField('Detalle adicional (si es "Otro")', el('input', { id: 'assign-note', type: 'text', class: 'input-full' }))
  );
  showModal('Asignación fuera del top sugerido', body, [
    { label: 'Cancelar', cls: 'btn btn-secondary', action: closeModal },
    {
      label: 'Registrar y asignar', cls: 'btn btn-warning', action: () => {
        const sup    = $id('assign-sup').value.trim();
        const reason = $id('assign-reason').value;
        const note   = $id('assign-note').value.trim();
        if (!sup || !reason) { toast('Supervisor y motivo son requeridos.', 'error'); return; }
        Models.addAuditLog({ supervisor_id: sup, chosen_employee: chosenId, suggested_top: topIds, reason, note });
        closeModal();
        toast('Asignación fuera del top registrada en audit log.', 'warning');
      }
    },
  ]);
}

// ─── Tab: Config ──────────────────────────────────────────────────────────────

function buildTabConfig() {
  const sec = el('div', { id: 'tab-config', class: 'tab-section' });
  sec.append(
    el('h2', { class: 'section-title' }, 'Configuración & Datos'),
    buildShiftConfig(),
    buildDataPanel()
  );
  return sec;
}


function buildShiftConfig() {
  const cfg = Models.getSystemConfig();
  const card = el('div', { class: 'card config-card' },
    el('h3', {}, 'Turno activo esta semana'),
    el('p', { class: 'muted' }, 'Controla que turno tiene las extras de dias habiles esta semana. Al guardar queda registrado en el historial.'),
    el('div', { class: 'toolbar' },
      el('select', { id: 'cfg-shift', class: 'input-full' },
        el('option', { value: 'mañana', ...(cfg.currentShiftWeek === 'mañana' ? { selected: '' } : {}) }, 'Mañana'),
        el('option', { value: 'tarde',  ...(cfg.currentShiftWeek === 'tarde'  ? { selected: '' } : {}) }, 'Tarde')
      ),
      el('button', { class: 'btn btn-primary', onclick: () => {
        const val = $id('cfg-shift').value;
        Models.registerShiftWeekChange(val);
        refreshShiftIndicator();
        renderShiftHistory();
        toast('Turno semana actualizado a: ' + val + ' (registrado en historial).', 'success');
      }}, 'Guardar')
    ),
    el('h4', { style: 'margin-top:20px;margin-bottom:8px' }, 'Historial de turnos semanales'),
    el('div', { id: 'shift-history' })
  );
  setTimeout(() => renderShiftHistory(), 0);
  return card;
}

function renderShiftHistory() {
  const cont = $id('shift-history');
  if (!cont) return;
  cont.innerHTML = '';
  const cfg = Models.getSystemConfig();
  const hist = (cfg.shiftHistory || []).slice().reverse().slice(0, 24);
  if (!hist.length) {
    cont.appendChild(el('p', { class: 'muted' }, 'Sin historial registrado. El historial se genera al guardar el turno semanal.'));
    return;
  }
  const tbl = el('table', { class: 'data-table' });
  tbl.appendChild(el('thead', {}, el('tr', {},
    el('th', {}, 'Semana (lunes)'), el('th', {}, 'Turno'), el('th', {}, 'Registrado el')
  )));
  const tbody = el('tbody');
  hist.forEach(h => {
    const badge = el('span', {
      class: 'badge ' + (h.turno === 'mañana' ? 'badge-success' : 'badge-type')
    }, h.turno);
    tbody.appendChild(el('tr', {},
      el('td', { class: 'mono' }, h.weekStart),
      el('td', {}, badge),
      el('td', { class: 'mono' }, new Date(h.changedAt).toLocaleDateString('es-AR'))
    ));
  });
  tbl.appendChild(tbody);
  cont.appendChild(tbl);
}

function buildDataPanel() {
  const card = el('div', { class: 'card config-card' },
    el('h3', {}, 'Importar / Exportar / Reportes'),
    el('div', { class: 'config-actions' },

      el('div', { class: 'config-action-group' },
        el('h4', {}, 'Exportar'),
        el('button', { class: 'btn btn-secondary', onclick: doExportJson },           '⬇ Exportar todo (JSON)'),
        el('button', { class: 'btn btn-secondary', onclick: doExportEmployeesCsv },   '⬇ Empleados (CSV)'),
        el('button', { class: 'btn btn-success',   onclick: doExportEmployeesXls },   '⬇ Empleados (XLS)'),
        el('button', { class: 'btn btn-secondary', onclick: doExportFilteredEvents }, '⬇ Exportar eventos (filtro fechas)'),
        el('button', { class: 'btn btn-secondary', onclick: openPrintableReport },    '🖨 Vista imprimible (PDF)'),
        el('button', { class: 'btn btn-success',   onclick: () => exportReportXls() },'⬇ Informe XLS'),
      ),

      el('div', { class: 'config-action-group' },
        el('h4', {}, 'Importar datos completos (JSON)'),
        el('p', { class: 'muted' }, 'Carga un archivo JSON exportado previamente. Reemplaza todos los datos actuales.'),
        el('input', { id: 'import-json-file', type: 'file', accept: '.json', class: 'input-full' }),
        el('button', { class: 'btn btn-warning', onclick: doImportJson }, '⬆ Importar JSON')
      ),

      el('div', { class: 'config-action-group danger-zone' },
        el('h4', { class: 'text-danger' }, '⚠️ Zona de peligro'),
        el('button', { class: 'btn btn-danger', onclick: doResetData }, '🗑 Borrar todos los datos locales')
      )
    )
  );

  // Date filter inputs (fuera del card para referenciarlos)
  const filterCard = el('div', { class: 'card config-card' },
    el('h3', {}, 'Filtro de fechas para exportación de eventos'),
    el('div', { class: 'toolbar' },
      el('label', {}, 'Desde ', el('input', { id: 'filter-from', type: 'date', class: 'input-sm' })),
      el('label', {}, 'Hasta ', el('input', { id: 'filter-to', type: 'date', class: 'input-sm' }))
    )
  );

  const recovCard = el('div', { class: 'card config-card' },
    el('h3', {}, 'Recuperación mensual de reputación'),
    el('p', { class: 'muted' }, `+${2} de reputación a empleados activos sin penalizaciones en el mes elegido. Ejecutá una sola vez por cierre mensual.`),
    el('div', { class: 'toolbar' },
      el('input', { id: 'recovery-month', type: 'month', class: 'input-sm', value: new Date().toISOString().slice(0, 7) }),
      el('button', { class: 'btn btn-success', onclick: doApplyMonthlyRecovery }, 'Aplicar recuperación mensual')
    )
  );

  return el('div', {}, card, filterCard, recovCard);
}

// ─── Exportaciones ────────────────────────────────────────────────────────────

function doExportJson() {
  const data = Models.exportState();
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  downloadBlob(blob, makeFilename('horas_extras_backup', 'json'));
  toast('Backup JSON descargado.', 'success');
}

function buildEmployeeExportRows(data) {
  return (data.employeesList || [])
    .map(id => data.employees[id])
    .filter(Boolean)
    .map(e => ({
      id: e.id,
      legajo:  e.legajo  || '',
      nombre:  e.name,
      puesto:  e.puesto  || '',
      telefono: e.telefono || '',
      turno:   e.turno_base,
      tipo:    e.tipo,
      antiguedad_meses: e.antiguedad_meses || 0,
      fecha_fin: e.fecha_fin || '',
      activo:  e.activo ? 'Si' : 'No',
      reputacion: e.reputation,
      horas_50: e.stats.horas_50,
      horas_100: e.stats.horas_100,
      convocado: e.stats.convocado,
      acepto:  e.stats.acepto,
      rechazo: e.stats.rechazo,
      falto:   e.stats.falto,
      sabados_trabajados: e.stats.sabados_trabajados,
    }));
}

function doExportEmployeesCsv() {
  const rows = buildEmployeeExportRows(Models.exportState());
  const blob = new Blob([toCSV(rows)], { type: 'text/csv;charset=utf-8' });
  downloadBlob(blob, makeFilename('empleados'));
  toast('CSV de empleados descargado.', 'success');
}

function doExportEmployeesXls() {
  const rows = buildEmployeeExportRows(Models.exportState());
  downloadBlob(toXLS(rows, 'Empleados'), makeFilename('empleados', 'xls'));
  toast('XLS de empleados descargado.', 'success');
}

function doExportSuggestionsCsv() {
  const list = Models.suggestionList();
  const rows = list.map((e, i) => ({
    posicion: i + 1, id: e.id, nombre: e.name, turno: e.turno_base, tipo: e.tipo,
    score: e.__meta.score.toFixed(2), reputacion: e.reputation,
    horas_50: e.stats.horas_50, horas_100: e.stats.horas_100, convocado: e.stats.convocado,
  }));
  const blob = new Blob([toCSV(rows)], { type: 'text/csv;charset=utf-8' });
  downloadBlob(blob, makeFilename('ranking_sugerencias'));
  toast('CSV de ranking descargado.', 'success');
}

function doExportFilteredEvents() {
  const from = $id('filter-from')?.value;
  const to   = $id('filter-to')?.value;
  if (!from || !to) { toast('Seleccioná el rango de fechas en el panel de configuración.', 'error'); return; }
  const st = new Date(from + 'T00:00:00');
  const ed = new Date(to   + 'T23:59:59');
  const data  = Models.exportState();

  const calls = Object.values(data.callEvents || {})
    .filter(c => { const d = new Date(c.fecha); return d >= st && d <= ed; })
    .map(c => ({
      id: c.id, empleado_id: c.empleado_id, fecha: c.fecha,
      tipo_extra: c.tipo_extra, resultado_final: c.resultado_final || 'pendiente',
      intentos: c.attempts?.length || 0,
    }));

  const satRows = [];
  for (const [key, ev] of Object.entries(data.saturdayEvents || {})) {
    for (const r of ev.records || []) {
      const d = r.ts ? new Date(r.ts) : new Date(key.replace(/_/g, '-'));
      if (d >= st && d <= ed) satRows.push({ fecha: key.replace(/_/g, '-'), empleado_id: r.employeeId || '', horas: r.hours || 0 });
    }
  }

  const b1 = new Blob([toCSV(calls)],   { type: 'text/csv;charset=utf-8' });
  const b2 = new Blob([toCSV(satRows)], { type: 'text/csv;charset=utf-8' });
  downloadBlob(b1, makeFilename('convocatorias_filtradas'));
  downloadBlob(b2, makeFilename('sabados_filtrados'));
  toast('Exportación de eventos descargada (2 archivos).', 'success');
}

function doImportJson() {
  const file = $id('import-json-file')?.files?.[0];
  if (!file) { toast('Seleccioná un archivo JSON para importar.', 'error'); return; }
  confirmModal('¿Reemplazar TODOS los datos locales con el contenido del archivo JSON? Esta acción no se puede deshacer.', () => {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result);
        Models.importState(data);
        renderEmployees();
        renderStats();
        renderCallHistory();
        renderSaturdayList();
        refreshShiftIndicator();
        toast('Datos importados correctamente.', 'success');
      } catch (e) { toast('Error al importar: ' + e.message, 'error'); }
    };
    reader.readAsText(file, 'UTF-8');
  });
}

function doResetData() {
  confirmModal('¿Borrar TODOS los datos locales? Esto eliminará empleados, convocatorias, sábados y logs. Esta acción es irreversible.', () => {
    // store.reset() se llama directamente (no expuesto en models)
    import('./store.js').then(m => {
      m.default.reset();
      renderEmployees();
      renderStats();
      renderCallHistory();
      renderSaturdayList();
      refreshShiftIndicator();
      toast('Todos los datos fueron eliminados.', 'warning');
    });
  });
}

// ─── Reporte imprimible ───────────────────────────────────────────────────────

function openPrintableReport() {
  const body = el('div', { class: 'form-grid' },
    formField('Empresa (opcional)', el('input', { id: 'report-company', type: 'text', class: 'input-full', placeholder: 'Ej: Frigorífico Ejemplo S.A.' })),
    formField('Mes', el('input', { id: 'report-month', type: 'month', class: 'input-full', value: new Date().toISOString().slice(0, 7) })),
    formField('Filtrar por turno', el('select', { id: 'report-turno', class: 'input-full' },
      el('option', { value: '' }, 'Todos los turnos'),
      el('option', { value: 'mañana' }, 'Mañana'),
      el('option', { value: 'tarde' }, 'Tarde')
    )),
    formField('Filtrar por tipo', el('select', { id: 'report-tipo', class: 'input-full' },
      el('option', { value: '' }, 'Todos los tipos'),
      el('option', { value: 'planta' }, 'Planta'),
      el('option', { value: 'eventual_simple' }, 'Eventual simple'),
      el('option', { value: 'eventual_comun' }, 'Eventual común')
    )),
    formField('', el('label', { style: 'display:flex;align-items:center;gap:8px;cursor:pointer;font-weight:500' },
      el('input', { id: 'report-activos', type: 'checkbox', checked: true, style: 'width:16px;height:16px;flex-shrink:0' }),
      'Solo empleados activos'
    ))
  );
  showModal('Generar reporte imprimible', body, [
    { label: 'Cancelar', cls: 'btn btn-secondary', action: closeModal },
    { label: '🖨 Abrir reporte', cls: 'btn btn-primary', action: generatePrintableReport },
  ]);
}

function generatePrintableReport() {
  const monthValue  = $id('report-month')?.value  || new Date().toISOString().slice(0, 7);
  const company     = $id('report-company')?.value.trim() || 'Horas Extras V2';
  const turnoFilter = $id('report-turno')?.value  || '';
  const tipoFilter  = $id('report-tipo')?.value   || '';
  const activosOnly = $id('report-activos')?.checked !== false;
  closeModal();

  const data = Models.exportState();
  let rows = data.employeesList.map(id => data.employees[id]).filter(Boolean);
  if (activosOnly)  rows = rows.filter(e => e.activo);
  if (turnoFilter)  rows = rows.filter(e => e.turno_base === turnoFilter);
  if (tipoFilter)   rows = rows.filter(e => e.tipo === tipoFilter);

  const filterParts = [
    turnoFilter ? 'Turno: ' + turnoFilter : '',
    tipoFilter  ? 'Tipo: '  + tipoFilter  : '',
    activosOnly ? 'Solo activos'          : 'Activos e inactivos',
  ].filter(Boolean);
  const filterDesc = filterParts.join(' · ');

  const tableRows = rows.map((e, i) => `<tr class="${e.activo ? '' : 'inactive'}">
        <td>${i + 1}</td>
        <td><code>${e.id}</code></td>
        <td>${e.legajo || '—'}</td>
        <td>${e.name}</td>
        <td>${e.puesto || '—'}</td>
        <td><span class="badge-turno ${e.turno_base === 'mañana' ? 't-m' : 't-t'}">${e.turno_base}</span></td>
        <td><span class="badge-tipo">${e.tipo}</span></td>
        <td>${e.activo ? 'Activo' : '<em>Inactivo</em>'}</td>
        <td><strong>${e.reputation}</strong></td>
        <td>${e.stats.horas_50}</td>
        <td>${e.stats.horas_100}</td>
        <td>${e.stats.convocado}</td>
        <td>${e.stats.acepto}</td>
        <td>${e.stats.falto}</td>
        <td>${e.stats.sabados_trabajados}</td>
      </tr>`).join('\n');

  const html = `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Reporte Horas Extras — ${monthValue}</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 20mm 15mm; color: #222; font-size: 12px; }
    .report-header { display: flex; justify-content: space-between; align-items: flex-start;
      border-bottom: 2px solid #333; padding-bottom: 12px; margin-bottom: 18px; }
    .report-company { font-size: 18px; font-weight: 700; }
    .report-title   { font-size: 14px; font-weight: 600; margin-top: 4px; }
    .report-meta    { text-align: right; font-size: 11px; color: #555; line-height: 1.7; }
    .report-filters { font-size: 11px; color: #888; margin-bottom: 12px; }
    table { width: 100%; border-collapse: collapse; margin-top: 6px; }
    th, td { border: 1px solid #ccc; padding: 5px 8px; text-align: left; font-size: 11px; }
    th { background: #f3f4f6; font-weight: 600; }
    tr:nth-child(even) { background: #fafafa; }
    .inactive { color: #9ca3af; font-style: italic; }
    .badge-turno { display:inline-block; padding:1px 6px; border-radius:3px; font-size:10px; font-weight:600; }
    .t-m { background:#dbeafe; color:#1d4ed8; }
    .t-t { background:#ffedd5; color:#c2410c; }
    .badge-tipo { display:inline-block; padding:1px 6px; border-radius:3px; font-size:10px; background:#f3f4f6; }
    .signature-row { display:flex; justify-content:flex-end; gap:60px; margin-top:48px; }
    .signature-box { text-align:center; width:200px; }
    .signature-line { border-top:1px solid #333; padding-top:6px; margin-top:40px; font-size:10px; color:#666; }
    .footer { margin-top:20px; font-size:10px; color:#aaa; text-align:center;
      border-top:1px solid #eee; padding-top:8px; }
    @media print { body { margin: 10mm; } }
  </style>
</head>
<body>
  <div class="report-header">
    <div>
      <div class="report-company">${company}</div>
      <div class="report-title">Reporte de Horas Extras — ${monthValue}</div>
    </div>
    <div class="report-meta">
      Generado: ${new Date().toLocaleString('es-AR')}<br>
      Empleados en reporte: <strong>${rows.length}</strong>
    </div>
  </div>
  <div class="report-filters">Filtros aplicados: ${filterDesc}</div>
  ${rows.length === 0
    ? '<p style="color:#888;font-style:italic">Sin empleados para los filtros seleccionados.</p>'
    : `<table>
    <thead>
      <tr>
        <th>#</th><th>ID</th><th>Legajo</th><th>Nombre</th><th>Puesto</th><th>Turno</th><th>Tipo</th><th>Estado</th>
        <th>Rep.</th><th>Hs 50%</th><th>Hs 100%</th>
        <th>Conv.</th><th>Aceptó</th><th>Faltó</th><th>Sáb.</th>
      </tr>
    </thead>
    <tbody>${tableRows}</tbody>
  </table>`
  }
  <div class="signature-row">
    <div class="signature-box"><div class="signature-line">Supervisor/a</div></div>
    <div class="signature-box"><div class="signature-line">Jefe/a de Planta</div></div>
  </div>
  <div class="footer">Horas Extras V2 — ${new Date().toLocaleString('es-AR')}</div>
</body>
</html>`;

  const w = window.open('', '_blank');
  if (!w) { toast('El navegador bloqueó la ventana emergente. Habilitá los popups para este sitio.', 'error'); return; }
  w.document.write(html);
  w.document.close();
  setTimeout(() => w.print(), 400);
}

function doExportReportXls() {
  const monthValue  = $id('report-month')?.value  || new Date().toISOString().slice(0, 7);
  const turnoFilter = $id('report-turno')?.value  || '';
  const tipoFilter  = $id('report-tipo')?.value   || '';
  const activosOnly = $id('report-activos')?.checked !== false;
  closeModal();

  const data = Models.exportState();
  let rows = data.employeesList.map(id => data.employees[id]).filter(Boolean);
  if (activosOnly)  rows = rows.filter(e => e.activo);
  if (turnoFilter)  rows = rows.filter(e => e.turno_base === turnoFilter);
  if (tipoFilter)   rows = rows.filter(e => e.tipo === tipoFilter);

  if (!rows.length) { toast('Sin empleados para los filtros seleccionados.', 'warning'); return; }

  const xlsRows = rows.map((e, i) => ({
    '#':              i + 1,
    'ID':             e.id,
    'Legajo':         e.legajo  || '',
    'Nombre':         e.name,
    'Puesto':         e.puesto  || '',
    'Teléfono':       e.telefono || '',
    'Turno':          e.turno_base,
    'Tipo':           e.tipo,
    'Estado':         e.activo ? 'Activo' : 'Inactivo',
    'Antigüedad (m)': e.antiguedad_meses || 0,
    'Fecha fin':      e.fecha_fin || '',
    'Reputación':     e.reputation,
    'Hs 50%':         e.stats.horas_50,
    'Hs 100%':        e.stats.horas_100,
    'Convocado':      e.stats.convocado,
    'Aceptó':         e.stats.acepto,
    'Rechazó':        e.stats.rechazo,
    'Faltó':          e.stats.falto,
    'Sáb. trabajados':e.stats.sabados_trabajados,
  }));

  downloadBlob(toXLS(xlsRows, 'Informe ' + monthValue), makeFilename('informe_' + monthValue, 'xls'));
  toast('XLS de informe descargado (' + rows.length + ' empleados).', 'success');
}

const exportReportXls = openPrintableReport;

function formField(label, inputEl) {
  return el('div', { class: 'form-field' },
    el('label', { class: 'form-label' }, label),
    inputEl
  );
}

function infoRow(label, value) {
  return el('div', { class: 'info-row' },
    el('span', { class: 'info-label' }, label + ':'),
    el('span', { class: 'info-value' }, String(value))
  );
}

// --- Reporte individual por empleado -----------------------------------------

function generateEmployeePrintableReport(id) {
  const e = Models.getEmployee(id);
  if (!e) { toast('Empleado no encontrado.', 'error'); return; }
  const confiabilidad = e.stats.convocado > 0
    ? ((e.stats.acepto / e.stats.convocado) * 100).toFixed(1) + '%'
    : 'N/A';
  const incRows = (e.incidents || []).map(inc =>
    `<tr>
      <td>${new Date(inc.ts).toLocaleDateString('es-AR')}</td>
      <td>${inc.reason}</td>
      <td style="text-align:center">${inc.delta}</td>
      <td>${inc.status}</td>
      <td>${inc.descargo?.text || '--'}</td>
    </tr>`
  ).join('');
  const html = `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Legajo - ${e.name}</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 24px; color: #222; }
    h1 { font-size: 20px; border-bottom: 2px solid #333; padding-bottom: 8px; }
    h2 { font-size: 15px; margin: 20px 0 8px; }
    .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 6px 24px; margin: 14px 0; font-size: 13px; }
    .row { display: flex; gap: 8px; }
    .lbl { font-weight: 600; min-width: 150px; }
    table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 12px; }
    th, td { border: 1px solid #ccc; padding: 6px 10px; text-align: left; }
    th { background: #f3f4f6; font-weight: 600; }
    tr:nth-child(even) { background: #fafafa; }
    .footer { margin-top: 32px; font-size: 11px; color: #777; }
    @media print { body { margin: 10mm; } }
  </style>
</head>
<body>
  <h1>Legajo de Horas Extras - ${e.name}</h1>
  <div class="info-grid">
    <div class="row"><span class="lbl">ID:</span><span>${e.id}</span></div>
    <div class="row"><span class="lbl">Legajo:</span><span>${e.legajo || '--'}</span></div>
    <div class="row"><span class="lbl">Turno base:</span><span>${e.turno_base}</span></div>
    <div class="row"><span class="lbl">Tipo:</span><span>${e.tipo}</span></div>
    <div class="row"><span class="lbl">Puesto:</span><span>${e.puesto || '--'}</span></div>
    <div class="row"><span class="lbl">Telefono:</span><span>${e.telefono || '--'}</span></div>
    <div class="row"><span class="lbl">Antiguedad:</span><span>${e.antiguedad_meses} meses</span></div>
    <div class="row"><span class="lbl">Fecha fin contrato:</span><span>${e.fecha_fin || '--'}</span></div>
    <div class="row"><span class="lbl">Activo:</span><span>${e.activo ? 'Si' : 'No'}</span></div>
    <div class="row"><span class="lbl">Reputacion:</span><span>${e.reputation} / 100</span></div>
    <div class="row"><span class="lbl">Confiabilidad:</span><span>${confiabilidad}</span></div>
    <div class="row"><span class="lbl">Horas 50%:</span><span>${e.stats.horas_50}</span></div>
    <div class="row"><span class="lbl">Horas 100%:</span><span>${e.stats.horas_100}</span></div>
    <div class="row"><span class="lbl">Convocado:</span><span>${e.stats.convocado}</span></div>
    <div class="row"><span class="lbl">Acepto:</span><span>${e.stats.acepto}</span></div>
    <div class="row"><span class="lbl">Rechazo:</span><span>${e.stats.rechazo}</span></div>
    <div class="row"><span class="lbl">No respondio:</span><span>${e.stats.no_respondio}</span></div>
    <div class="row"><span class="lbl">Numero incorrecto:</span><span>${e.stats.numero_incorrecto}</span></div>
    <div class="row"><span class="lbl">Falto:</span><span>${e.stats.falto}</span></div>
    <div class="row"><span class="lbl">Sabados trabajados:</span><span>${e.stats.sabados_trabajados}</span></div>
  </div>
  <h2>Historial de incidentes (${(e.incidents || []).length})</h2>
  ${incRows ? `<table>
    <thead><tr>
      <th>Fecha</th><th>Motivo</th><th>Delta rep.</th><th>Estado</th><th>Descargo</th>
    </tr></thead>
    <tbody>${incRows}</tbody>
  </table>` : '<p style="color:#777">Sin incidentes registrados.</p>'}
  <div class="footer">Generado: ${new Date().toLocaleString()} - Horas Extras V2 (offline)</div>
</body>
</html>`;
  const w = window.open('', '_blank');
  w.document.write(html);
  w.document.close();
  setTimeout(() => w.print(), 400);
}

// --- Cierre mensual ----------------------------------------------------------

function doApplyMonthlyRecovery() {
  const month = $id('recovery-month')?.value;
  if (!month) { toast('Selecciona el mes.', 'error'); return; }
  confirmModal(
    '¿Aplicar recuperación de reputación (+2) para el mes ' + month + '? Solo afecta a empleados activos sin penalizaciones en ese período. Esta acción no se puede revertir.',
    () => {
      try {
        const count = Models.applyMonthlyRecovery(month);
        renderStats();
        if (count > 0) {
          toast('Recuperación mensual aplicada: ' + count + ' empleado(s) recibieron +2 de reputación.', 'success');
        } else {
          toast('No hubo empleados elegibles sin penalizaciones en ' + month + '.', 'info');
        }
      } catch (err) { toast(err.message, 'error'); }
    }
  );
}

// --- Inicializacion ----------------------------------------------------------

document.addEventListener('DOMContentLoaded', () => {
  const expiredDescargas = Models.expireStaleDescargas();
  const deactivated      = Models.deactivateExpiredEventuals();
  Models.purgeOldWeekAvailability();   // limpia semanas viejas (> 8 sem)
  weekPlannerKey = Models.getISOWeekKey(); // reset al arrancar
  if (expiredDescargas > 0) {
    startupAlerts.push({ type: 'warning', msg: `⏰ Se cerraron automáticamente ${expiredDescargas} descargo(s) por vencimiento del plazo de 48 h.` });
  }
  if (deactivated.length > 0) {
    const names = deactivated.map(id => {
      const e = Models.getEmployee(id);
      return e ? `${e.name} (${e.id})` : id;
    }).join(', ');
    startupAlerts.push({ type: 'danger', msg: `⚠️ ${deactivated.length} empleado(s) desactivado(s) por fin de contrato: ${names}. Verificá en la pestaña Empleados.` });
  }
  mountUI();
  renderAlertBar();
});

export default {};
