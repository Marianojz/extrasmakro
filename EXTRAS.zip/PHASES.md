# PHASES.md — Fases del proyecto: Horas Extras V2

> **Documento congelado.**
> Detalla cada fase con objetivos, entregables, criterios de éxito y dependencias.
> Para el detalle de tareas pendientes por fase, ver `ROADMAP.md`.
> Última actualización: 25/02/2026

---

## Mapa de fases

```
Fase 0  ──►  Fase 1  ──►  Fase 2  ──►  Fase 3  ──►  Fase 4  ──►  Fase 5
 Base         Offline       UX/Bugs       Avanzado      Firebase      Producción
  ✅            ✅            ✅            ✅             🔲             🔲
```

---

## Fase 0 — Estructura base ✅

**Objetivo:** Establecer la arquitectura de carpetas, archivos semilla y documentación inicial sin escribir lógica de negocio.

**Entregables:**
- `public/index.html` (shell limpio)
- `src/` con archivos vacíos o placeholders
- `package.json` (sin dependencias, scripts placeholder)
- `CONTEXT.md` con restricciones del entorno
- `README.md` con propósito del proyecto
- `src/firebaseConfig.js` con placeholders de credenciales

**Criterio de éxito:** El HTML abre en el navegador sin errores; todos los archivos existen con estructura coherente.

**Dependencias:** Ninguna.

---

## Fase 1 — Implementación offline ✅

**Objetivo:** Construir el núcleo funcional completo de la aplicación usando exclusivamente `localStorage`, sin dependencias externas.

**Entregables:**
- `src/config.js` — configuración global centralizada (penalizaciones, flags, constantes)
- `src/storage/adapter.js` — interfaz + esquema canónico `INITIAL_STATE`
- `src/storage/localStorageAdapter.js` — persistencia offline robusta con manejo de corrupción
- `src/storage/firebaseAdapter.js` — stub completo con estructura Firestore propuesta y reglas de seguridad documentadas
- `src/storage/index.js` — selector de adapter según `FIREBASE_ENABLED`
- `src/store.js` — re-export del adapter activo
- `src/models.js` — lógica de negocio completa:
  - Empleados (CRUD, vacíos, desactivación)
  - Convocatorias (2 intentos, estados terminales, lógica de `no_respondio`)
  - Sábados (`horas_100`, recuperación de reputación)
  - Días hábiles (Caso A / Caso B según turno)
  - Descargos (ventana 48 h, reversión de penalización, cierre automático)
  - Audit logs (protección contra decisiones arbitrarias)
  - Scoring v2.1 (con penalización por baja confiabilidad)
  - Import/Export de estado completo
- `src/utils.js` — `toCSV`, `parseCSV`, `downloadBlob`, `makeFilename`

**Bugs corregidos en esta fase:**
- `generateId()` reseteaba el contador a cada ID.
- `parseCSV` no exportada.
- `addCallAttempt` cerraba con `no_respondio` al 1er intento.
- `openPrintableReport()` usaba variable `month` sin declarar.

**Criterio de éxito:** Se pueden crear empleados, hacer convocatorias completas, registrar sábados y días hábiles, gestionar descargos, y exportar/importar datos — todo sin conexión a internet.

**Dependencias:** Fase 0 completa.

---

## Fase 2 — UX y mejoras de interfaz ✅

**Objetivo:** Reemplazar la UI mínima (con `alert`/`prompt`/`confirm`) por una interfaz profesional con navegación, modales, toasts y estilos completos.

**Entregables:**
- `src/app.js` reescrito:
  - 5 tabs de navegación: Empleados | Convocatorias | Sábados | Estadísticas | Config
  - Sistema de toasts (reemplaza todos los `alert`/`confirm`/`prompt`)
  - Modales de formulario para todas las operaciones de entrada
  - Tabla de empleados con búsqueda incremental y paginación
  - Tabla de ranking con score, confiabilidad, reputación y trofeos
  - Dashboard de 4 tarjetas estadísticas
  - Flujo de convocatoria en 2 pasos (crear → registrar intento)
  - Gestión de descargos inline en el detalle del empleado
  - Panel de config con todas las opciones de datos
  - Reporte imprimible con auto-print
  - Indicador de turno activo en header
- `src/styles.css` completamente renovado:
  - Custom properties (paleta uniforme)
  - Navegación sticky con tab indicator
  - Componentes: botones (6 variantes), badges, rep-scores, stat-cards, data-tables
  - Toasts con animación y 4 tipos (info/success/warning/error)
  - Modales con animación slideUp + fadeIn backdrop
  - Responsive para móvil (breakpoint 700px)
  - Print styles
- `public/index.html` limpio (sin markup muerto del prototipo)

**Criterio de éxito:** Un supervisor no programador puede usar toda la aplicación sin encontrarse con `alert()` del browser ni necesitar conocimientos técnicos. La UI es clara en desktop y usable en móvil.

**Dependencias:** Fase 1 completa.

---

## Fase 3 — Funcionalidades operativas avanzadas ✅

**Objetivo:** Cubrir los flujos operativos que quedaron pendientes: intención de sábados, cierre automático de descargos vencidos, dashboard de jefe, recuperación mensual de reputación y PDF refinado.

**Entregables completados:**
- ✅ `expireStaleDescargas()` en models.js — cierra automáticamente descargos sin texto al superar 48 h, ejecutado al inicio de la app
- ✅ `deactivateExpiredEventuals()` en models.js — desactiva empleados `eventual_comun` cuya `fecha_fin` ya pasó, ejecutado al inicio
- ✅ Banner de alertas dismissable en la barra superior: notifica descargos cerrados y eventuales desactivados
- ✅ `applyMonthlyRecovery(yearMonth)` en models.js — aplica recuperación +2 a empleados activos sin penalizaciones en el mes indicado
- ✅ `getAuditLogs()` en models.js — devuelve el audit log ordenado descendente
- ✅ Validación de nombres duplicados en alta de empleados
- ✅ Panel de jefe en tab Estadísticas: tabla "Top incumplidores" y tabla de audit log completo
- ✅ Reporte imprimible individual por empleado (desde el modal de detalle)
- ✅ UI de recuperación mensual en tab Config con selector de mes y confirmación
- ✅ UI de intención de sábado: flujo de 3 fases (intenciones → asignación → registro de horas)
- ✅ Calendario/historial de turno semanal en tab Config (últimas 24 semanas)
- ✅ Reporte global imprimible mejorado: filtros por turno/tipo/activos, empresa, firmas, badges visuales

**Criterio de éxito:** Un jefe puede auditar completamente el sistema sin necesidad de exportar datos manualmente. El cierre mensual se ejecuta con un solo clic.

**Dependencias:** Fase 2 completa.

---

## Fase 4 — Cableado Firebase + despliegue 🔲

**Objetivo:** Conectar la aplicación a Firebase/Firestore y desplegarla en producción (GitHub + Vercel), manteniendo retrocompatibilidad con el modo offline.

**Prerequisitos del entorno (bloqueantes):**
- Acceso a internet desde la máquina de trabajo.
- Permisos para ejecutar `npm install`.
- Cuenta de Firebase (proyecto creado).
- Repositorio GitHub creado.
- Cuenta de Vercel.

**Entregables planeados:**
- `src/storage/firebaseAdapter.js` completado (descomentar secciones `[FIREBASE]`)
- `src/firebaseConfig.js` con credenciales reales
- `src/config.js`: `FIREBASE_ENABLED: true`
- Script de migración: JSON local → Firestore
- Firebase Auth integrado (supervisor/jefe)
- Reglas de seguridad Firestore aplicadas
- `README.md` actualizado con instrucciones de despliegue
- Pipeline CI/CD en GitHub Actions + Vercel
- Variables de entorno en Vercel (credenciales Firebase)

**Criterio de éxito:** La aplicación funciona en producción en una URL pública, con datos en Firestore, autenticación activa y despliegue automático en cada push a `main`.

**Dependencias:** Fase 3 completa + internet + npm + credenciales Firebase.

---

## Fase 5 — Producción, control y mantenimiento 🔲

**Objetivo:** Asegurar que el sistema sea confiable en producción, auditado, con backups y procesos de cierre mensual automáticos.

**Entregables planeados:**
- Pruebas de aceptación con supervisores (UAT — User Acceptance Testing)
- Revisión legal/sindical del modelo de reputación y descargos con el departamento de RRHH
- Política de retención de datos documentada y configurada en Firestore
- Backups automáticos (exportación Firestore programada)
- Cloud Function (o cron Vercel) para `applyMonthlyRecovery()` y cierre de descargos
- Notificaciones por email/push para descargos próximos a vencer (48 h)
- Monitoreo de errores (Sentry o similar)
- Documentación de usuario (manual de operación para supervisores)

**Criterio de éxito:** El sistema funciona sin intervención técnica durante al menos un mes completo. Los supervisores lo usan de forma autónoma. Los reportes mensuales se generan automáticamente.

**Dependencias:** Fase 4 completa + aprobación legal/sindical.

---

## Resumen de decisiones de arquitectura

| Decisión | Aplica desde | Descripción |
|--|--|--|
| Adapter pattern para storage | Fase 1 | Permite pasar de localStorage a Firebase sin cambiar models.js ni app.js |
| ES Modules nativos (sin bundler) | Fase 0 | Funciona en browser sin herramientas de build |
| Config centralizada en `config.js` | Fase 1 | Penalizaciones, flags y constantes en un solo lugar |
| Reputación acumulada, nunca reseteada | Fase 1 | Requisito operativo explícito |
| Descargo con ventana de 48 h | Fase 1 | Equilibrio entre urgencia operativa y derecho del empleado |
| `no_respondio` cierra solo al 2do intento | Fase 1 | Permite un 2do intento antes de penalizar |
| Tabs para navegación (sin router) | Fase 2 | Sin router library, show/hide de secciones |
| Toast system en lugar de alert() | Fase 2 | UX profesional sin dependencias |

---

## Cambios al documento

| Fecha | Cambio | Razón |
|--|--|--|
| 25/02/2026 | Documento creado y congelado | Formalización de la arquitectura del proyecto |
| 25/02/2026 | Fase 3 marcada como en curso | Implementación parcial: mantenimiento automático, panel jefe, reporte individual, recuperación mensual |
| 25/02/2026 | Fase 3 completada — todas las funcionalidades operativas implementadas | Banner alertas, reporte mejorado con filtros, UI sábados 3 fases, historial turno |
