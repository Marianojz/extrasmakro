﻿# CONTEXT.md — Contexto del proyecto: Horas Extras V2

> **Documento congelado.** Actualizarlo únicamente cuando cambien restricciones o decisiones de arquitectura fundamentales.
> Última actualización: 25/02/2026

---

## 1. Descripción general

Sistema web SPA (Single Page Application) para gestionar **convocatorias y horas extras** de empleados, con motor de reputación, algoritmo de prioridad y registros de auditoría.

- Funciona **100 % offline** usando `localStorage` como persistencia.
- Preparado para conectar **Firebase / Firestore** en el futuro (cableado listo, ver Sección 6).
- No requiere instalación de dependencias para funcionar en modo offline.
- Pensado para supervisores y jefes de área, sin acceso a internet desde la máquina de trabajo.

---

## 2. Entorno del usuario

| Variable | Valor |
|--|--|
| Sistema operativo | Windows |
| Acceso a Internet | ❌ No (en la máquina de trabajo) |
| Permisos de instalación | ❌ No (no se puede ejecutar npm, pip, etc.) |
| Conocimientos técnicos | GitHub, Firebase, Vercel — no programa |
| Herramienta de desarrollo | VS Code con GitHub Copilot |

---

## 3. Stack técnico

| Capa | Tecnología |
|--|--|
| Lenguaje | JavaScript (ES Modules, sin transpilación) |
| UI | Vanilla JS (DOM manual, sin framework) |
| Estilos | CSS nativo (custom properties, grid, flexbox) |
| Persistencia offline | `window.localStorage` |
| Persistencia futura | Firebase / Firestore (stub listo en `src/storage/firebaseAdapter.js`) |
| Bundler | Ninguno (carga directa en browser) |
| Despliegue futuro | GitHub + Vercel (instrucciones en README.md) |

---

## 4. Modelo de dominio

### 4.1 Empleados

Campos: `id`, `name`, `turno_base` (mañana|tarde), `tipo` (efectivo|eventual_comun|eventual_especial), `antiguedad_meses`, `activo`, `fecha_fin`, `reputation` (0-100), `stats`, `incidents`, `createdAt`.

- Los `eventual_comun` tienen `fecha_fin`. Los `eventual_especial` son indefinidos.
- La variable global `systemConfig.currentShiftWeek` determina qué turno tiene extras activas cada semana.

### 4.2 Horas extras — Días hábiles

- **Caso A (turno mañana):** se queda hasta 18:00 → +3 `horas_50`.
- **Caso B (turno tarde):** entra 10:00–22:00 → +3 `horas_100`.
- Hora de comida: no se paga, no se calcula, no es editable.
- Las horas se suman automáticamente; nunca manualmente en días hábiles.

### 4.3 Sábados

- Estructura: `/saturdayEvents/YYYY_MM_DD`.
- Flujo: intención el viernes → supervisor asigna → se cargan horas reales manuales → todo suma a `horas_100`.
- Sin almuerzo ni descuentos.

### 4.4 Convocatorias (Protocolo de llamadas)

Cada convocatoria crea un `callEvent` con:
`empleado_id`, `fecha`, `tipo_extra`, `intento_1`, `intento_2`, `resultado_final`, `supervisor_id`, `timestamp`.

**Estados posibles:** `confirmado`, `rechazo`, `no_respondio`, `numero_incorrecto`, `atendio_otro`, `falto`.

Máximo 2 intentos. El sistema bloquea el tercero.

`no_respondio` solo cierra la convocatoria al 2do intento (puede haber un 2do intento).

### 4.5 Estadísticas

Nunca se reinician. Acumulativas en `/employees[id].stats`:
`horas_50`, `horas_100`, `convocado`, `acepto`, `rechazo`, `no_respondio`, `numero_incorrecto`, `falto`, `sabados_trabajados`.

Reportes mensuales se filtran por fecha de eventos.

### 4.6 Algoritmo de prioridad (v2.1)

```
score = (total_horas × 3) + convocado − (reputationScore × 0.5)
```

**Menor score → mayor prioridad.** Penalización +20 al score si `confiabilidad < 0.5` y `convocado > 0`.

### 4.7 Reputación (v2.1)

- Rango: 0–100. Inicial: 100.
- **Penalizaciones automáticas:** falta −15, no respondió −5, número incorrecto −10, rechazo −3.
- Estado inicial del incidente: `pendiente_descargo`.
- **Ventana de descargo:** 48 h desde el incidente.
  - Si se aprueba → se revierte la penalización, estado `revertido`.
  - Si se rechaza → se mantiene, estado `rechazado`.
  - Si vence sin descargo → estado `cerrado_sin_descargo`.
- **Recuperación:** extra cumplida +1 pt; mes sin incidentes +2 pt; cap 100.

### 4.8 Protección contra decisiones arbitrarias

Si el supervisor asigna fuera del top sugerido, debe seleccionar motivo:
`urgencia_operativa`, `experiencia_requerida`, `rotacion_excepcional`, `otro`.
Se guarda en `/auditLogs`.

---

## 5. Arquitectura de archivos

```
public/
  index.html               — Shell HTML (mínima, app se monta via JS)

src/
  config.js                — Configuración global (FIREBASE_ENABLED, penalizaciones, etc.)
  app.js                   — UI: tabs, modales, toasts, render functions
  models.js                — Lógica de negocio (dominio puro)
  store.js                 — Re-exporta el adapter activo (retrocompatibilidad)
  utils.js                 — Utilidades: toCSV, parseCSV, downloadBlob, makeFilename
  styles.css               — Estilos completos (custom properties, responsive)
  firebaseConfig.js        — Placeholder de credenciales Firebase

  storage/
    adapter.js             — Interfaz conceptual + INITIAL_STATE (esquema de datos)
    localStorageAdapter.js — Implementación offline (síncrona)
    firebaseAdapter.js     — Stub Firebase (asíncrona, comentado)
    index.js               — Selector de adapter según FIREBASE_ENABLED
```

---

## 6. Cableado Firebase (pendiente de activar)

Todo el código de integración está escrito y documentado. Para activarlo:

1. Ejecutar: `npm install firebase`
2. Completar `src/firebaseConfig.js` con las credenciales del proyecto Firebase.
3. En `src/config.js`, cambiar: `FIREBASE_ENABLED: true`
4. El sistema usará `firebaseAdapter.js` automáticamente.
5. Los métodos del adapter son `async` → revisar que `models.js` y `app.js` usen `await`.

Estructura Firestore propuesta:
```
/systemConfig/app
/employees/{id}
/callEvents/{id}
/saturdayEvents/{YYYY_MM_DD}
/auditLogs/{id}
```

---

## 7. Decisiones de diseño registradas

| Decisión | Razón |
|--|--|
| Vanilla JS sin framework | Sin internet, sin instalación posible |
| ES Modules en browser | Soportados nativamente, no requieren bundler |
| Adapter pattern para storage | Permite cambiar a Firebase sin tocar models.js ni app.js |
| Stats acumulativas, nunca reseteadas | Requisito operativo explícito |
| ID autoincremental (no UUID) | Legibilidad en tablas y logs |
| `no_respondio` cierra solo al 2do intento | Permite un segundo intento sin penalizar prematuramente |
| Descargo: 48 h de ventana | Equilibrio entre urgencia operativa y derecho del empleado |

---

## 8. Bugs corregidos en v2 (25/02/2026)

| Bug | Archivo | Descripción |
|--|--|--|
| `generateId()` no avanzaba | `models.js` | `state.nextIdCounter = id` reseteaba el contador al valor pre-increment. Cada empleado recibía el mismo ID. |
| `month` variable `undefined` | `app.js` | `openPrintableReport()` usaba `month` sin declarar. El reporte generaba un error silencioso. |
| `parseCSV` no exportada | `utils.js` | La función se usaba en `app.js` pero no figuraba en el `export`. |
| `addCallAttempt` cerraba inmediatamente con `no_respondio` | `models.js` | Debe cerrar solo al 2do intento, no al 1ro. |
| `resolveDescargo` revertía mal la reputación | `models.js` | La lógica era correcta pero dependía de que `inc.delta` fuera negativo; ahora es explícito. |
| `index.html` tenía sección muerta `#add-hours` | `index.html` | Markup del prototipo inicial, nunca conectado a la lógica real. |


---
